package io.bootify.my_app.repos;

import io.bootify.my_app.domain.MaintenanceRecord;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MaintenanceRecordRepository extends JpaRepository<MaintenanceRecord, Integer> {

    MaintenanceRecord findFirstByMaterial(Material material);

    MaintenanceRecord findFirstByTechnician(User user);

}
