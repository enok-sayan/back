package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ReceptionDTO;
import io.bootify.my_app.repos.SupplierRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.ReceptionService;
import io.bootify.my_app.util.CustomCollectors;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/receptions", produces = MediaType.APPLICATION_JSON_VALUE)
public class ReceptionResource {

    private final ReceptionService receptionService;
    private final SupplierRepository supplierRepository;
    private final UserRepository userRepository;

    public ReceptionResource(final ReceptionService receptionService,
            final SupplierRepository supplierRepository, final UserRepository userRepository) {
        this.receptionService = receptionService;
        this.supplierRepository = supplierRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<ReceptionDTO>> getAllReceptions() {
        return ResponseEntity.ok(receptionService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReceptionDTO> getReception(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(receptionService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createReception(
            @RequestBody @Valid final ReceptionDTO receptionDTO) {
        final Integer createdId = receptionService.create(receptionDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateReception(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ReceptionDTO receptionDTO) {
        receptionService.update(id, receptionDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReception(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = receptionService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        receptionService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/supplierValues")
    public ResponseEntity<Map<Integer, Integer>> getSupplierValues() {
        return ResponseEntity.ok(supplierRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Supplier::getId, Supplier::getId)));
    }

    @GetMapping("/receivedByUserValues")
    public ResponseEntity<Map<Integer, Integer>> getReceivedByUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

}
