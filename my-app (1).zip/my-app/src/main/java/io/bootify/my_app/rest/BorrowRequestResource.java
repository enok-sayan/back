package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.BorrowRequestDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.BorrowRequestService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/borrowRequests", produces = MediaType.APPLICATION_JSON_VALUE)
public class BorrowRequestResource {

    private final BorrowRequestService borrowRequestService;
    private final UserRepository userRepository;
    private final MaterialRepository materialRepository;

    public BorrowRequestResource(final BorrowRequestService borrowRequestService,
            final UserRepository userRepository, final MaterialRepository materialRepository) {
        this.borrowRequestService = borrowRequestService;
        this.userRepository = userRepository;
        this.materialRepository = materialRepository;
    }

    @GetMapping
    public ResponseEntity<List<BorrowRequestDTO>> getAllBorrowRequests() {
        return ResponseEntity.ok(borrowRequestService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<BorrowRequestDTO> getBorrowRequest(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(borrowRequestService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createBorrowRequest(
            @RequestBody @Valid final BorrowRequestDTO borrowRequestDTO) {
        final Integer createdId = borrowRequestService.create(borrowRequestDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateBorrowRequest(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final BorrowRequestDTO borrowRequestDTO) {
        borrowRequestService.update(id, borrowRequestDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBorrowRequest(@PathVariable(name = "id") final Integer id) {
        borrowRequestService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/userValues")
    public ResponseEntity<Map<Integer, Integer>> getUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

}
