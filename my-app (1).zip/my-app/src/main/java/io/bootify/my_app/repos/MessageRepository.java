package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Message;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MessageRepository extends JpaRepository<Message, Integer> {

    Message findFirstBySender(User user);

    Message findFirstByReceiver(User user);

    Message findFirstByParentMessageAndIdNot(Message message, final Integer id);

}
