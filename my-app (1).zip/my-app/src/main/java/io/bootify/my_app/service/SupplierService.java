package io.bootify.my_app.service;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.model.SupplierDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.ReceptionRepository;
import io.bootify.my_app.repos.SupplierRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class SupplierService {

    private final SupplierRepository supplierRepository;
    private final MaterialRepository materialRepository;
    private final ReceptionRepository receptionRepository;

    public SupplierService(final SupplierRepository supplierRepository,
            final MaterialRepository materialRepository,
            final ReceptionRepository receptionRepository) {
        this.supplierRepository = supplierRepository;
        this.materialRepository = materialRepository;
        this.receptionRepository = receptionRepository;
    }

    public List<SupplierDTO> findAll() {
        final List<Supplier> suppliers = supplierRepository.findAll(Sort.by("id"));
        return suppliers.stream()
                .map(supplier -> mapToDTO(supplier, new SupplierDTO()))
                .toList();
    }

    public SupplierDTO get(final Integer id) {
        return supplierRepository.findById(id)
                .map(supplier -> mapToDTO(supplier, new SupplierDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final SupplierDTO supplierDTO) {
        final Supplier supplier = new Supplier();
        mapToEntity(supplierDTO, supplier);
        return supplierRepository.save(supplier).getId();
    }

    public void update(final Integer id, final SupplierDTO supplierDTO) {
        final Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(supplierDTO, supplier);
        supplierRepository.save(supplier);
    }

    public void delete(final Integer id) {
        supplierRepository.deleteById(id);
    }

    private SupplierDTO mapToDTO(final Supplier supplier, final SupplierDTO supplierDTO) {
        supplierDTO.setId(supplier.getId());
        supplierDTO.setCreatedAt(supplier.getCreatedAt());
        supplierDTO.setName(supplier.getName());
        supplierDTO.setContactPerson(supplier.getContactPerson());
        supplierDTO.setPhone(supplier.getPhone());
        supplierDTO.setEmail(supplier.getEmail());
        supplierDTO.setAddress(supplier.getAddress());
        return supplierDTO;
    }

    private Supplier mapToEntity(final SupplierDTO supplierDTO, final Supplier supplier) {
        supplier.setCreatedAt(supplierDTO.getCreatedAt());
        supplier.setName(supplierDTO.getName());
        supplier.setContactPerson(supplierDTO.getContactPerson());
        supplier.setPhone(supplierDTO.getPhone());
        supplier.setEmail(supplierDTO.getEmail());
        supplier.setAddress(supplierDTO.getAddress());
        return supplier;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Material supplierMaterial = materialRepository.findFirstBySupplier(supplier);
        if (supplierMaterial != null) {
            referencedWarning.setKey("supplier.material.supplier.referenced");
            referencedWarning.addParam(supplierMaterial.getId());
            return referencedWarning;
        }
        final Reception supplierReception = receptionRepository.findFirstBySupplier(supplier);
        if (supplierReception != null) {
            referencedWarning.setKey("supplier.reception.supplier.referenced");
            referencedWarning.addParam(supplierReception.getId());
            return referencedWarning;
        }
        return null;
    }

}
