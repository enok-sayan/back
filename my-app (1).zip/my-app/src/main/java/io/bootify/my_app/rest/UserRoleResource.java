package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Role;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.UserRoleDTO;
import io.bootify.my_app.repos.RoleRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.UserRoleService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/userRoles", produces = MediaType.APPLICATION_JSON_VALUE)
public class UserRoleResource {

    private final UserRoleService userRoleService;
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public UserRoleResource(final UserRoleService userRoleService,
            final UserRepository userRepository, final RoleRepository roleRepository) {
        this.userRoleService = userRoleService;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    @GetMapping
    public ResponseEntity<List<UserRoleDTO>> getAllUserRoles() {
        return ResponseEntity.ok(userRoleService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserRoleDTO> getUserRole(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(userRoleService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createUserRole(
            @RequestBody @Valid final UserRoleDTO userRoleDTO) {
        final Integer createdId = userRoleService.create(userRoleDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateUserRole(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final UserRoleDTO userRoleDTO) {
        userRoleService.update(id, userRoleDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUserRole(@PathVariable(name = "id") final Integer id) {
        userRoleService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/userValues")
    public ResponseEntity<Map<Integer, Integer>> getUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

    @GetMapping("/roleValues")
    public ResponseEntity<Map<Integer, Integer>> getRoleValues() {
        return ResponseEntity.ok(roleRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Role::getId, Role::getId)));
    }

}
