package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.OffsetDateTime;


public class ReceptionItemDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private Integer quantityReceived;

    private String batchNumber;

    private LocalDate expiryDate;

    private Integer reception;

    private Integer material;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getQuantityReceived() {
        return quantityReceived;
    }

    public void setQuantityReceived(final Integer quantityReceived) {
        this.quantityReceived = quantityReceived;
    }

    public String getBatchNumber() {
        return batchNumber;
    }

    public void setBatchNumber(final String batchNumber) {
        this.batchNumber = batchNumber;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(final LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Integer getReception() {
        return reception;
    }

    public void setReception(final Integer reception) {
        this.reception = reception;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

}
