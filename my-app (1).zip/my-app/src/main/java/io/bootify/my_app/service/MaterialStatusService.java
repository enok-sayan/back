package io.bootify.my_app.service;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.MaterialStatus;
import io.bootify.my_app.model.MaterialStatusDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.MaterialStatusRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class MaterialStatusService {

    private final MaterialStatusRepository materialStatusRepository;
    private final MaterialRepository materialRepository;

    public MaterialStatusService(final MaterialStatusRepository materialStatusRepository,
            final MaterialRepository materialRepository) {
        this.materialStatusRepository = materialStatusRepository;
        this.materialRepository = materialRepository;
    }

    public List<MaterialStatusDTO> findAll() {
        final List<MaterialStatus> materialStatuses = materialStatusRepository.findAll(Sort.by("id"));
        return materialStatuses.stream()
                .map(materialStatus -> mapToDTO(materialStatus, new MaterialStatusDTO()))
                .toList();
    }

    public MaterialStatusDTO get(final Integer id) {
        return materialStatusRepository.findById(id)
                .map(materialStatus -> mapToDTO(materialStatus, new MaterialStatusDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final MaterialStatusDTO materialStatusDTO) {
        final MaterialStatus materialStatus = new MaterialStatus();
        mapToEntity(materialStatusDTO, materialStatus);
        return materialStatusRepository.save(materialStatus).getId();
    }

    public void update(final Integer id, final MaterialStatusDTO materialStatusDTO) {
        final MaterialStatus materialStatus = materialStatusRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(materialStatusDTO, materialStatus);
        materialStatusRepository.save(materialStatus);
    }

    public void delete(final Integer id) {
        materialStatusRepository.deleteById(id);
    }

    private MaterialStatusDTO mapToDTO(final MaterialStatus materialStatus,
            final MaterialStatusDTO materialStatusDTO) {
        materialStatusDTO.setId(materialStatus.getId());
        materialStatusDTO.setCreatedAt(materialStatus.getCreatedAt());
        materialStatusDTO.setName(materialStatus.getName());
        materialStatusDTO.setDescription(materialStatus.getDescription());
        return materialStatusDTO;
    }

    private MaterialStatus mapToEntity(final MaterialStatusDTO materialStatusDTO,
            final MaterialStatus materialStatus) {
        materialStatus.setCreatedAt(materialStatusDTO.getCreatedAt());
        materialStatus.setName(materialStatusDTO.getName());
        materialStatus.setDescription(materialStatusDTO.getDescription());
        return materialStatus;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final MaterialStatus materialStatus = materialStatusRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Material materialStatusMaterial = materialRepository.findFirstByMaterialStatus(materialStatus);
        if (materialStatusMaterial != null) {
            referencedWarning.setKey("materialStatus.material.materialStatus.referenced");
            referencedWarning.addParam(materialStatusMaterial.getId());
            return referencedWarning;
        }
        return null;
    }

}
