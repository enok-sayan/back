package io.bootify.my_app.model;

import java.time.OffsetDateTime;


public class BorrowRequestDTO {

    private Integer id;
    private OffsetDateTime createdAt;
    private OffsetDateTime requestDate;
    private OffsetDateTime startDate;
    private OffsetDateTime endDate;
    private String status;
    private String purpose;
    private String comments;
    private Integer user;
    private Integer material;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public OffsetDateTime getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(final OffsetDateTime requestDate) {
        this.requestDate = requestDate;
    }

    public OffsetDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(final OffsetDateTime startDate) {
        this.startDate = startDate;
    }

    public OffsetDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(final OffsetDateTime endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(final String purpose) {
        this.purpose = purpose;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(final String comments) {
        this.comments = comments;
    }

    public Integer getUser() {
        return user;
    }

    public void setUser(final Integer user) {
        this.user = user;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

}
