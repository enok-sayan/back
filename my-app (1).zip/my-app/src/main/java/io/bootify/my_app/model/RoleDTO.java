package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.OffsetDateTime;


public class RoleDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

}
