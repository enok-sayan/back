package io.bootify.my_app.rest;

import io.bootify.my_app.model.MaterialStatusDTO;
import io.bootify.my_app.service.MaterialStatusService;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/materialStatuses", produces = MediaType.APPLICATION_JSON_VALUE)
public class MaterialStatusResource {

    private final MaterialStatusService materialStatusService;

    public MaterialStatusResource(final MaterialStatusService materialStatusService) {
        this.materialStatusService = materialStatusService;
    }

    @GetMapping
    public ResponseEntity<List<MaterialStatusDTO>> getAllMaterialStatuses() {
        return ResponseEntity.ok(materialStatusService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MaterialStatusDTO> getMaterialStatus(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(materialStatusService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createMaterialStatus(
            @RequestBody @Valid final MaterialStatusDTO materialStatusDTO) {
        final Integer createdId = materialStatusService.create(materialStatusDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateMaterialStatus(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final MaterialStatusDTO materialStatusDTO) {
        materialStatusService.update(id, materialStatusDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMaterialStatus(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = materialStatusService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        materialStatusService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
