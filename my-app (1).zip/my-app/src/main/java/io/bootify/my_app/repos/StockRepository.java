package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Stock;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StockRepository extends JpaRepository<Stock, Integer> {

    Stock findFirstByMaterial(Material material);

    Stock findFirstByLocation(Location location);

}
