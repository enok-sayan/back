package io.bootify.my_app.service;

import io.bootify.my_app.domain.Message;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.MessageDTO;
import io.bootify.my_app.repos.MessageRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class MessageService {

    private final MessageRepository messageRepository;
    private final UserRepository userRepository;

    public MessageService(final MessageRepository messageRepository,
            final UserRepository userRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
    }

    public List<MessageDTO> findAll() {
        final List<Message> messages = messageRepository.findAll(Sort.by("id"));
        return messages.stream()
                .map(message -> mapToDTO(message, new MessageDTO()))
                .toList();
    }

    public MessageDTO get(final Integer id) {
        return messageRepository.findById(id)
                .map(message -> mapToDTO(message, new MessageDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final MessageDTO messageDTO) {
        final Message message = new Message();
        mapToEntity(messageDTO, message);
        return messageRepository.save(message).getId();
    }

    public void update(final Integer id, final MessageDTO messageDTO) {
        final Message message = messageRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(messageDTO, message);
        messageRepository.save(message);
    }

    public void delete(final Integer id) {
        messageRepository.deleteById(id);
    }

    private MessageDTO mapToDTO(final Message message, final MessageDTO messageDTO) {
        messageDTO.setId(message.getId());
        messageDTO.setCreatedAt(message.getCreatedAt());
        messageDTO.setSubject(message.getSubject());
        messageDTO.setContent(message.getContent());
        messageDTO.setSentAt(message.getSentAt());
        messageDTO.setReadAt(message.getReadAt());
        messageDTO.setSender(message.getSender() == null ? null : message.getSender().getId());
        messageDTO.setReceiver(message.getReceiver() == null ? null : message.getReceiver().getId());
        messageDTO.setParentMessage(message.getParentMessage() == null ? null : message.getParentMessage().getId());
        return messageDTO;
    }

    private Message mapToEntity(final MessageDTO messageDTO, final Message message) {
        message.setCreatedAt(messageDTO.getCreatedAt());
        message.setSubject(messageDTO.getSubject());
        message.setContent(messageDTO.getContent());
        message.setSentAt(messageDTO.getSentAt());
        message.setReadAt(messageDTO.getReadAt());
        final User sender = messageDTO.getSender() == null ? null : userRepository.findById(messageDTO.getSender())
                .orElseThrow(() -> new NotFoundException("sender not found"));
        message.setSender(sender);
        final User receiver = messageDTO.getReceiver() == null ? null : userRepository.findById(messageDTO.getReceiver())
                .orElseThrow(() -> new NotFoundException("receiver not found"));
        message.setReceiver(receiver);
        final Message parentMessage = messageDTO.getParentMessage() == null ? null : messageRepository.findById(messageDTO.getParentMessage())
                .orElseThrow(() -> new NotFoundException("parentMessage not found"));
        message.setParentMessage(parentMessage);
        return message;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Message message = messageRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Message parentMessageMessage = messageRepository.findFirstByParentMessageAndIdNot(message, message.getId());
        if (parentMessageMessage != null) {
            referencedWarning.setKey("message.message.parentMessage.referenced");
            referencedWarning.addParam(parentMessageMessage.getId());
            return referencedWarning;
        }
        return null;
    }

}
