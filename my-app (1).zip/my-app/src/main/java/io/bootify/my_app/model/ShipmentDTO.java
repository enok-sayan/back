package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.OffsetDateTime;


public class ShipmentDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private LocalDate shipmentDate;

    private String status;

    private Integer client;

    private Integer shippedByUser;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getShipmentDate() {
        return shipmentDate;
    }

    public void setShipmentDate(final LocalDate shipmentDate) {
        this.shipmentDate = shipmentDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public Integer getClient() {
        return client;
    }

    public void setClient(final Integer client) {
        this.client = client;
    }

    public Integer getShippedByUser() {
        return shippedByUser;
    }

    public void setShippedByUser(final Integer shippedByUser) {
        this.shippedByUser = shippedByUser;
    }

}
