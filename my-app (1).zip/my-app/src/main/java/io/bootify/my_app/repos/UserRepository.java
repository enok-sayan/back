package io.bootify.my_app.repos;

import io.bootify.my_app.domain.User;
import io.bootify.my_app.domain.UserType;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User, Integer> {

    User findFirstByUserType(UserType userType);

}
