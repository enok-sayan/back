package io.bootify.my_app.service;

import io.bootify.my_app.domain.Client;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.model.ClientDTO;
import io.bootify.my_app.repos.ClientRepository;
import io.bootify.my_app.repos.ShipmentRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ClientService {

    private final ClientRepository clientRepository;
    private final ShipmentRepository shipmentRepository;

    public ClientService(final ClientRepository clientRepository,
            final ShipmentRepository shipmentRepository) {
        this.clientRepository = clientRepository;
        this.shipmentRepository = shipmentRepository;
    }

    public List<ClientDTO> findAll() {
        final List<Client> clients = clientRepository.findAll(Sort.by("id"));
        return clients.stream()
                .map(client -> mapToDTO(client, new ClientDTO()))
                .toList();
    }

    public ClientDTO get(final Integer id) {
        return clientRepository.findById(id)
                .map(client -> mapToDTO(client, new ClientDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ClientDTO clientDTO) {
        final Client client = new Client();
        mapToEntity(clientDTO, client);
        return clientRepository.save(client).getId();
    }

    public void update(final Integer id, final ClientDTO clientDTO) {
        final Client client = clientRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(clientDTO, client);
        clientRepository.save(client);
    }

    public void delete(final Integer id) {
        clientRepository.deleteById(id);
    }

    private ClientDTO mapToDTO(final Client client, final ClientDTO clientDTO) {
        clientDTO.setId(client.getId());
        clientDTO.setCreatedAt(client.getCreatedAt());
        clientDTO.setName(client.getName());
        clientDTO.setContactPerson(client.getContactPerson());
        clientDTO.setPhone(client.getPhone());
        clientDTO.setEmail(client.getEmail());
        clientDTO.setAddress(client.getAddress());
        return clientDTO;
    }

    private Client mapToEntity(final ClientDTO clientDTO, final Client client) {
        client.setCreatedAt(clientDTO.getCreatedAt());
        client.setName(clientDTO.getName());
        client.setContactPerson(clientDTO.getContactPerson());
        client.setPhone(clientDTO.getPhone());
        client.setEmail(clientDTO.getEmail());
        client.setAddress(clientDTO.getAddress());
        return client;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Client client = clientRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Shipment clientShipment = shipmentRepository.findFirstByClient(client);
        if (clientShipment != null) {
            referencedWarning.setKey("client.shipment.client.referenced");
            referencedWarning.addParam(clientShipment.getId());
            return referencedWarning;
        }
        return null;
    }

}
