package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.StockMovement;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StockMovementRepository extends JpaRepository<StockMovement, Integer> {

    StockMovement findFirstByMaterial(Material material);

    StockMovement findFirstByLocation(Location location);

    StockMovement findFirstByUser(User user);

}
