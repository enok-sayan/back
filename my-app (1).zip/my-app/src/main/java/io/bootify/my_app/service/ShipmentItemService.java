package io.bootify.my_app.service;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.domain.ShipmentItem;
import io.bootify.my_app.model.ShipmentItemDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.ShipmentItemRepository;
import io.bootify.my_app.repos.ShipmentRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ShipmentItemService {

    private final ShipmentItemRepository shipmentItemRepository;
    private final ShipmentRepository shipmentRepository;
    private final MaterialRepository materialRepository;

    public ShipmentItemService(final ShipmentItemRepository shipmentItemRepository,
            final ShipmentRepository shipmentRepository,
            final MaterialRepository materialRepository) {
        this.shipmentItemRepository = shipmentItemRepository;
        this.shipmentRepository = shipmentRepository;
        this.materialRepository = materialRepository;
    }

    public List<ShipmentItemDTO> findAll() {
        final List<ShipmentItem> shipmentItems = shipmentItemRepository.findAll(Sort.by("id"));
        return shipmentItems.stream()
                .map(shipmentItem -> mapToDTO(shipmentItem, new ShipmentItemDTO()))
                .toList();
    }

    public ShipmentItemDTO get(final Integer id) {
        return shipmentItemRepository.findById(id)
                .map(shipmentItem -> mapToDTO(shipmentItem, new ShipmentItemDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ShipmentItemDTO shipmentItemDTO) {
        final ShipmentItem shipmentItem = new ShipmentItem();
        mapToEntity(shipmentItemDTO, shipmentItem);
        return shipmentItemRepository.save(shipmentItem).getId();
    }

    public void update(final Integer id, final ShipmentItemDTO shipmentItemDTO) {
        final ShipmentItem shipmentItem = shipmentItemRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(shipmentItemDTO, shipmentItem);
        shipmentItemRepository.save(shipmentItem);
    }

    public void delete(final Integer id) {
        shipmentItemRepository.deleteById(id);
    }

    private ShipmentItemDTO mapToDTO(final ShipmentItem shipmentItem,
            final ShipmentItemDTO shipmentItemDTO) {
        shipmentItemDTO.setId(shipmentItem.getId());
        shipmentItemDTO.setCreatedAt(shipmentItem.getCreatedAt());
        shipmentItemDTO.setQuantityShipped(shipmentItem.getQuantityShipped());
        shipmentItemDTO.setShipment(shipmentItem.getShipment() == null ? null : shipmentItem.getShipment().getId());
        shipmentItemDTO.setMaterial(shipmentItem.getMaterial() == null ? null : shipmentItem.getMaterial().getId());
        return shipmentItemDTO;
    }

    private ShipmentItem mapToEntity(final ShipmentItemDTO shipmentItemDTO,
            final ShipmentItem shipmentItem) {
        shipmentItem.setCreatedAt(shipmentItemDTO.getCreatedAt());
        shipmentItem.setQuantityShipped(shipmentItemDTO.getQuantityShipped());
        final Shipment shipment = shipmentItemDTO.getShipment() == null ? null : shipmentRepository.findById(shipmentItemDTO.getShipment())
                .orElseThrow(() -> new NotFoundException("shipment not found"));
        shipmentItem.setShipment(shipment);
        final Material material = shipmentItemDTO.getMaterial() == null ? null : materialRepository.findById(shipmentItemDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        shipmentItem.setMaterial(material);
        return shipmentItem;
    }

}
