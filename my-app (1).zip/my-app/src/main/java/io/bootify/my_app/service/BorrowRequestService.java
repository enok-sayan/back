package io.bootify.my_app.service;

import io.bootify.my_app.domain.BorrowRequest;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.BorrowRequestDTO;
import io.bootify.my_app.repos.BorrowRequestRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class BorrowRequestService {

    private final BorrowRequestRepository borrowRequestRepository;
    private final UserRepository userRepository;
    private final MaterialRepository materialRepository;

    public BorrowRequestService(final BorrowRequestRepository borrowRequestRepository,
            final UserRepository userRepository, final MaterialRepository materialRepository) {
        this.borrowRequestRepository = borrowRequestRepository;
        this.userRepository = userRepository;
        this.materialRepository = materialRepository;
    }

    public List<BorrowRequestDTO> findAll() {
        final List<BorrowRequest> borrowRequests = borrowRequestRepository.findAll(Sort.by("id"));
        return borrowRequests.stream()
                .map(borrowRequest -> mapToDTO(borrowRequest, new BorrowRequestDTO()))
                .toList();
    }

    public BorrowRequestDTO get(final Integer id) {
        return borrowRequestRepository.findById(id)
                .map(borrowRequest -> mapToDTO(borrowRequest, new BorrowRequestDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final BorrowRequestDTO borrowRequestDTO) {
        final BorrowRequest borrowRequest = new BorrowRequest();
        mapToEntity(borrowRequestDTO, borrowRequest);
        return borrowRequestRepository.save(borrowRequest).getId();
    }

    public void update(final Integer id, final BorrowRequestDTO borrowRequestDTO) {
        final BorrowRequest borrowRequest = borrowRequestRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(borrowRequestDTO, borrowRequest);
        borrowRequestRepository.save(borrowRequest);
    }

    public void delete(final Integer id) {
        borrowRequestRepository.deleteById(id);
    }

    private BorrowRequestDTO mapToDTO(final BorrowRequest borrowRequest,
            final BorrowRequestDTO borrowRequestDTO) {
        borrowRequestDTO.setId(borrowRequest.getId());
        borrowRequestDTO.setCreatedAt(borrowRequest.getCreatedAt());
        borrowRequestDTO.setRequestDate(borrowRequest.getRequestDate());
        borrowRequestDTO.setStartDate(borrowRequest.getStartDate());
        borrowRequestDTO.setEndDate(borrowRequest.getEndDate());
        borrowRequestDTO.setStatus(borrowRequest.getStatus());
        borrowRequestDTO.setPurpose(borrowRequest.getPurpose());
        borrowRequestDTO.setComments(borrowRequest.getComments());
        borrowRequestDTO.setUser(borrowRequest.getUser() == null ? null : borrowRequest.getUser().getId());
        borrowRequestDTO.setMaterial(borrowRequest.getMaterial() == null ? null : borrowRequest.getMaterial().getId());
        return borrowRequestDTO;
    }

    private BorrowRequest mapToEntity(final BorrowRequestDTO borrowRequestDTO,
            final BorrowRequest borrowRequest) {
        borrowRequest.setCreatedAt(borrowRequestDTO.getCreatedAt());
        borrowRequest.setRequestDate(borrowRequestDTO.getRequestDate());
        borrowRequest.setStartDate(borrowRequestDTO.getStartDate());
        borrowRequest.setEndDate(borrowRequestDTO.getEndDate());
        borrowRequest.setStatus(borrowRequestDTO.getStatus());
        borrowRequest.setPurpose(borrowRequestDTO.getPurpose());
        borrowRequest.setComments(borrowRequestDTO.getComments());
        final User user = borrowRequestDTO.getUser() == null ? null : userRepository.findById(borrowRequestDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        borrowRequest.setUser(user);
        final Material material = borrowRequestDTO.getMaterial() == null ? null : materialRepository.findById(borrowRequestDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        borrowRequest.setMaterial(material);
        return borrowRequest;
    }

}
