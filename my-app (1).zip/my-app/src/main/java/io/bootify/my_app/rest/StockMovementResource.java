package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.StockMovementDTO;
import io.bootify.my_app.repos.LocationRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.StockMovementService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/stockMovements", produces = MediaType.APPLICATION_JSON_VALUE)
public class StockMovementResource {

    private final StockMovementService stockMovementService;
    private final MaterialRepository materialRepository;
    private final LocationRepository locationRepository;
    private final UserRepository userRepository;

    public StockMovementResource(final StockMovementService stockMovementService,
            final MaterialRepository materialRepository,
            final LocationRepository locationRepository, final UserRepository userRepository) {
        this.stockMovementService = stockMovementService;
        this.materialRepository = materialRepository;
        this.locationRepository = locationRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<StockMovementDTO>> getAllStockMovements() {
        return ResponseEntity.ok(stockMovementService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StockMovementDTO> getStockMovement(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(stockMovementService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createStockMovement(
            @RequestBody @Valid final StockMovementDTO stockMovementDTO) {
        final Integer createdId = stockMovementService.create(stockMovementDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateStockMovement(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final StockMovementDTO stockMovementDTO) {
        stockMovementService.update(id, stockMovementDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStockMovement(@PathVariable(name = "id") final Integer id) {
        stockMovementService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

    @GetMapping("/locationValues")
    public ResponseEntity<Map<Integer, Integer>> getLocationValues() {
        return ResponseEntity.ok(locationRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Location::getId, Location::getId)));
    }

    @GetMapping("/userValues")
    public ResponseEntity<Map<Integer, Integer>> getUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

}
