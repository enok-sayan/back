package io.bootify.my_app.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.OffsetDateTime;


public class AlertDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    private String alertType;

    private String message;

    private OffsetDateTime timestamp;

    @JsonProperty("isRead")
    private Boolean isRead;

    private Integer user;

    private Integer material;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getAlertType() {
        return alertType;
    }

    public void setAlertType(final String alertType) {
        this.alertType = alertType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public OffsetDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(final OffsetDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(final Boolean isRead) {
        this.isRead = isRead;
    }

    public Integer getUser() {
        return user;
    }

    public void setUser(final Integer user) {
        this.user = user;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

}
