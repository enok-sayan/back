package io.bootify.my_app.service;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.ReceptionItem;
import io.bootify.my_app.model.ReceptionItemDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.ReceptionItemRepository;
import io.bootify.my_app.repos.ReceptionRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ReceptionItemService {

    private final ReceptionItemRepository receptionItemRepository;
    private final ReceptionRepository receptionRepository;
    private final MaterialRepository materialRepository;

    public ReceptionItemService(final ReceptionItemRepository receptionItemRepository,
            final ReceptionRepository receptionRepository,
            final MaterialRepository materialRepository) {
        this.receptionItemRepository = receptionItemRepository;
        this.receptionRepository = receptionRepository;
        this.materialRepository = materialRepository;
    }

    public List<ReceptionItemDTO> findAll() {
        final List<ReceptionItem> receptionItems = receptionItemRepository.findAll(Sort.by("id"));
        return receptionItems.stream()
                .map(receptionItem -> mapToDTO(receptionItem, new ReceptionItemDTO()))
                .toList();
    }

    public ReceptionItemDTO get(final Integer id) {
        return receptionItemRepository.findById(id)
                .map(receptionItem -> mapToDTO(receptionItem, new ReceptionItemDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ReceptionItemDTO receptionItemDTO) {
        final ReceptionItem receptionItem = new ReceptionItem();
        mapToEntity(receptionItemDTO, receptionItem);
        return receptionItemRepository.save(receptionItem).getId();
    }

    public void update(final Integer id, final ReceptionItemDTO receptionItemDTO) {
        final ReceptionItem receptionItem = receptionItemRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(receptionItemDTO, receptionItem);
        receptionItemRepository.save(receptionItem);
    }

    public void delete(final Integer id) {
        receptionItemRepository.deleteById(id);
    }

    private ReceptionItemDTO mapToDTO(final ReceptionItem receptionItem,
            final ReceptionItemDTO receptionItemDTO) {
        receptionItemDTO.setId(receptionItem.getId());
        receptionItemDTO.setCreatedAt(receptionItem.getCreatedAt());
        receptionItemDTO.setQuantityReceived(receptionItem.getQuantityReceived());
        receptionItemDTO.setBatchNumber(receptionItem.getBatchNumber());
        receptionItemDTO.setExpiryDate(receptionItem.getExpiryDate());
        receptionItemDTO.setReception(receptionItem.getReception() == null ? null : receptionItem.getReception().getId());
        receptionItemDTO.setMaterial(receptionItem.getMaterial() == null ? null : receptionItem.getMaterial().getId());
        return receptionItemDTO;
    }

    private ReceptionItem mapToEntity(final ReceptionItemDTO receptionItemDTO,
            final ReceptionItem receptionItem) {
        receptionItem.setCreatedAt(receptionItemDTO.getCreatedAt());
        receptionItem.setQuantityReceived(receptionItemDTO.getQuantityReceived());
        receptionItem.setBatchNumber(receptionItemDTO.getBatchNumber());
        receptionItem.setExpiryDate(receptionItemDTO.getExpiryDate());
        final Reception reception = receptionItemDTO.getReception() == null ? null : receptionRepository.findById(receptionItemDTO.getReception())
                .orElseThrow(() -> new NotFoundException("reception not found"));
        receptionItem.setReception(reception);
        final Material material = receptionItemDTO.getMaterial() == null ? null : materialRepository.findById(receptionItemDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        receptionItem.setMaterial(material);
        return receptionItem;
    }

}
