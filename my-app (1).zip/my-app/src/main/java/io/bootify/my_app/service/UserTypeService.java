package io.bootify.my_app.service;

import io.bootify.my_app.domain.User;
import io.bootify.my_app.domain.UserType;
import io.bootify.my_app.model.UserTypeDTO;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.repos.UserTypeRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class UserTypeService {

    private final UserTypeRepository userTypeRepository;
    private final UserRepository userRepository;

    public UserTypeService(final UserTypeRepository userTypeRepository,
            final UserRepository userRepository) {
        this.userTypeRepository = userTypeRepository;
        this.userRepository = userRepository;
    }

    public List<UserTypeDTO> findAll() {
        final List<UserType> userTypes = userTypeRepository.findAll(Sort.by("id"));
        return userTypes.stream()
                .map(userType -> mapToDTO(userType, new UserTypeDTO()))
                .toList();
    }

    public UserTypeDTO get(final Integer id) {
        return userTypeRepository.findById(id)
                .map(userType -> mapToDTO(userType, new UserTypeDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final UserTypeDTO userTypeDTO) {
        final UserType userType = new UserType();
        mapToEntity(userTypeDTO, userType);
        return userTypeRepository.save(userType).getId();
    }

    public void update(final Integer id, final UserTypeDTO userTypeDTO) {
        final UserType userType = userTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(userTypeDTO, userType);
        userTypeRepository.save(userType);
    }

    public void delete(final Integer id) {
        userTypeRepository.deleteById(id);
    }

    private UserTypeDTO mapToDTO(final UserType userType, final UserTypeDTO userTypeDTO) {
        userTypeDTO.setId(userType.getId());
        userTypeDTO.setCreatedAt(userType.getCreatedAt());
        userTypeDTO.setName(userType.getName());
        userTypeDTO.setDescription(userType.getDescription());
        userTypeDTO.setPermissionLevel(userType.getPermissionLevel());
        return userTypeDTO;
    }

    private UserType mapToEntity(final UserTypeDTO userTypeDTO, final UserType userType) {
        userType.setCreatedAt(userTypeDTO.getCreatedAt());
        userType.setName(userTypeDTO.getName());
        userType.setDescription(userTypeDTO.getDescription());
        userType.setPermissionLevel(userTypeDTO.getPermissionLevel());
        return userType;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final UserType userType = userTypeRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final User userTypeUser = userRepository.findFirstByUserType(userType);
        if (userTypeUser != null) {
            referencedWarning.setKey("userType.user.userType.referenced");
            referencedWarning.addParam(userTypeUser.getId());
            return referencedWarning;
        }
        return null;
    }

}
