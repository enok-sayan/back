package io.bootify.my_app.service;

import io.bootify.my_app.domain.ActivityLog;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ActivityLogDTO;
import io.bootify.my_app.repos.ActivityLogRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ActivityLogService {

    private final ActivityLogRepository activityLogRepository;
    private final UserRepository userRepository;

    public ActivityLogService(final ActivityLogRepository activityLogRepository,
            final UserRepository userRepository) {
        this.activityLogRepository = activityLogRepository;
        this.userRepository = userRepository;
    }

    public List<ActivityLogDTO> findAll() {
        final List<ActivityLog> activityLogs = activityLogRepository.findAll(Sort.by("id"));
        return activityLogs.stream()
                .map(activityLog -> mapToDTO(activityLog, new ActivityLogDTO()))
                .toList();
    }

    public ActivityLogDTO get(final Integer id) {
        return activityLogRepository.findById(id)
                .map(activityLog -> mapToDTO(activityLog, new ActivityLogDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ActivityLogDTO activityLogDTO) {
        final ActivityLog activityLog = new ActivityLog();
        mapToEntity(activityLogDTO, activityLog);
        return activityLogRepository.save(activityLog).getId();
    }

    public void update(final Integer id, final ActivityLogDTO activityLogDTO) {
        final ActivityLog activityLog = activityLogRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(activityLogDTO, activityLog);
        activityLogRepository.save(activityLog);
    }

    public void delete(final Integer id) {
        activityLogRepository.deleteById(id);
    }

    private ActivityLogDTO mapToDTO(final ActivityLog activityLog,
            final ActivityLogDTO activityLogDTO) {
        activityLogDTO.setId(activityLog.getId());
        activityLogDTO.setCreatedAt(activityLog.getCreatedAt());
        activityLogDTO.setAction(activityLog.getAction());
        activityLogDTO.setDetails(activityLog.getDetails());
        activityLogDTO.setTimestamp(activityLog.getTimestamp());
        activityLogDTO.setUser(activityLog.getUser() == null ? null : activityLog.getUser().getId());
        return activityLogDTO;
    }

    private ActivityLog mapToEntity(final ActivityLogDTO activityLogDTO,
            final ActivityLog activityLog) {
        activityLog.setCreatedAt(activityLogDTO.getCreatedAt());
        activityLog.setAction(activityLogDTO.getAction());
        activityLog.setDetails(activityLogDTO.getDetails());
        activityLog.setTimestamp(activityLogDTO.getTimestamp());
        final User user = activityLogDTO.getUser() == null ? null : userRepository.findById(activityLogDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        activityLog.setUser(user);
        return activityLog;
    }

}
