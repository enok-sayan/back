package io.bootify.my_app.rest;

import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ActivityLogDTO;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.ActivityLogService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/activityLogs", produces = MediaType.APPLICATION_JSON_VALUE)
public class ActivityLogResource {

    private final ActivityLogService activityLogService;
    private final UserRepository userRepository;

    public ActivityLogResource(final ActivityLogService activityLogService,
            final UserRepository userRepository) {
        this.activityLogService = activityLogService;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<ActivityLogDTO>> getAllActivityLogs() {
        return ResponseEntity.ok(activityLogService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ActivityLogDTO> getActivityLog(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(activityLogService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createActivityLog(
            @RequestBody @Valid final ActivityLogDTO activityLogDTO) {
        final Integer createdId = activityLogService.create(activityLogDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateActivityLog(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ActivityLogDTO activityLogDTO) {
        activityLogService.update(id, activityLogDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteActivityLog(@PathVariable(name = "id") final Integer id) {
        activityLogService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/userValues")
    public ResponseEntity<Map<Integer, Integer>> getUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

}
