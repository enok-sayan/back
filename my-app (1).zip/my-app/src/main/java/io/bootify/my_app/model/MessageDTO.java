package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.OffsetDateTime;


public class MessageDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private String subject;

    @NotNull
    private String content;

    private OffsetDateTime sentAt;

    private OffsetDateTime readAt;

    private Integer sender;

    private Integer receiver;

    private Integer parentMessage;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(final String subject) {
        this.subject = subject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(final String content) {
        this.content = content;
    }

    public OffsetDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(final OffsetDateTime sentAt) {
        this.sentAt = sentAt;
    }

    public OffsetDateTime getReadAt() {
        return readAt;
    }

    public void setReadAt(final OffsetDateTime readAt) {
        this.readAt = readAt;
    }

    public Integer getSender() {
        return sender;
    }

    public void setSender(final Integer sender) {
        this.sender = sender;
    }

    public Integer getReceiver() {
        return receiver;
    }

    public void setReceiver(final Integer receiver) {
        this.receiver = receiver;
    }

    public Integer getParentMessage() {
        return parentMessage;
    }

    public void setParentMessage(final Integer parentMessage) {
        this.parentMessage = parentMessage;
    }

}
