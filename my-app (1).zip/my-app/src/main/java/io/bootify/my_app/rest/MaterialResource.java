package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Category;
import io.bootify.my_app.domain.Manufacturer;
import io.bootify.my_app.domain.MaterialStatus;
import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.model.MaterialDTO;
import io.bootify.my_app.repos.CategoryRepository;
import io.bootify.my_app.repos.ManufacturerRepository;
import io.bootify.my_app.repos.MaterialStatusRepository;
import io.bootify.my_app.repos.SupplierRepository;
import io.bootify.my_app.service.MaterialService;
import io.bootify.my_app.util.CustomCollectors;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/materials", produces = MediaType.APPLICATION_JSON_VALUE)
public class MaterialResource {

    private final MaterialService materialService;
    private final CategoryRepository categoryRepository;
    private final MaterialStatusRepository materialStatusRepository;
    private final SupplierRepository supplierRepository;
    private final ManufacturerRepository manufacturerRepository;

    public MaterialResource(final MaterialService materialService,
            final CategoryRepository categoryRepository,
            final MaterialStatusRepository materialStatusRepository,
            final SupplierRepository supplierRepository,
            final ManufacturerRepository manufacturerRepository) {
        this.materialService = materialService;
        this.categoryRepository = categoryRepository;
        this.materialStatusRepository = materialStatusRepository;
        this.supplierRepository = supplierRepository;
        this.manufacturerRepository = manufacturerRepository;
    }

    @GetMapping
    public ResponseEntity<List<MaterialDTO>> getAllMaterials() {
        return ResponseEntity.ok(materialService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MaterialDTO> getMaterial(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(materialService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createMaterial(
            @RequestBody @Valid final MaterialDTO materialDTO) {
        final Integer createdId = materialService.create(materialDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateMaterial(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final MaterialDTO materialDTO) {
        materialService.update(id, materialDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMaterial(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = materialService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        materialService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/categoryValues")
    public ResponseEntity<Map<Integer, Integer>> getCategoryValues() {
        return ResponseEntity.ok(categoryRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Category::getId, Category::getId)));
    }

    @GetMapping("/materialStatusValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialStatusValues() {
        return ResponseEntity.ok(materialStatusRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(MaterialStatus::getId, MaterialStatus::getId)));
    }

    @GetMapping("/supplierValues")
    public ResponseEntity<Map<Integer, Integer>> getSupplierValues() {
        return ResponseEntity.ok(supplierRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Supplier::getId, Supplier::getId)));
    }

    @GetMapping("/manufacturerValues")
    public ResponseEntity<Map<Integer, Integer>> getManufacturerValues() {
        return ResponseEntity.ok(manufacturerRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Manufacturer::getId, Manufacturer::getId)));
    }

}
