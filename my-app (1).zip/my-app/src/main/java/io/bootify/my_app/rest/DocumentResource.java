package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.model.DocumentDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.service.DocumentService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/documents", produces = MediaType.APPLICATION_JSON_VALUE)
public class DocumentResource {

    private final DocumentService documentService;
    private final MaterialRepository materialRepository;

    public DocumentResource(final DocumentService documentService,
            final MaterialRepository materialRepository) {
        this.documentService = documentService;
        this.materialRepository = materialRepository;
    }

    @GetMapping
    public ResponseEntity<List<DocumentDTO>> getAllDocuments() {
        return ResponseEntity.ok(documentService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<DocumentDTO> getDocument(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(documentService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createDocument(
            @RequestBody @Valid final DocumentDTO documentDTO) {
        final Integer createdId = documentService.create(documentDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateDocument(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final DocumentDTO documentDTO) {
        documentService.update(id, documentDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDocument(@PathVariable(name = "id") final Integer id) {
        documentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

}
