package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.OffsetDateTime;


public class ReceptionDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private LocalDate receptionDate;

    private String status;

    private Integer supplier;

    private Integer receivedByUser;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDate getReceptionDate() {
        return receptionDate;
    }

    public void setReceptionDate(final LocalDate receptionDate) {
        this.receptionDate = receptionDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public Integer getSupplier() {
        return supplier;
    }

    public void setSupplier(final Integer supplier) {
        this.supplier = supplier;
    }

    public Integer getReceivedByUser() {
        return receivedByUser;
    }

    public void setReceivedByUser(final Integer receivedByUser) {
        this.receivedByUser = receivedByUser;
    }

}
