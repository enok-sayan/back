package io.bootify.my_app.model;

import java.time.OffsetDateTime;


public class StockMovementDTO {

    private Integer id;
    private OffsetDateTime createdAt;
    private String type;
    private Integer quantityChange;
    private Integer newQuantity;
    private OffsetDateTime timestamp;
    private Integer material;
    private Integer location;
    private Integer user;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public Integer getQuantityChange() {
        return quantityChange;
    }

    public void setQuantityChange(final Integer quantityChange) {
        this.quantityChange = quantityChange;
    }

    public Integer getNewQuantity() {
        return newQuantity;
    }

    public void setNewQuantity(final Integer newQuantity) {
        this.newQuantity = newQuantity;
    }

    public OffsetDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(final OffsetDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

    public Integer getLocation() {
        return location;
    }

    public void setLocation(final Integer location) {
        this.location = location;
    }

    public Integer getUser() {
        return user;
    }

    public void setUser(final Integer user) {
        this.user = user;
    }

}
