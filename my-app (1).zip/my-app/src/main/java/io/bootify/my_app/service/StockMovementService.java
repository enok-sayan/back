package io.bootify.my_app.service;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.StockMovement;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.StockMovementDTO;
import io.bootify.my_app.repos.LocationRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.StockMovementRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class StockMovementService {

    private final StockMovementRepository stockMovementRepository;
    private final MaterialRepository materialRepository;
    private final LocationRepository locationRepository;
    private final UserRepository userRepository;

    public StockMovementService(final StockMovementRepository stockMovementRepository,
            final MaterialRepository materialRepository,
            final LocationRepository locationRepository, final UserRepository userRepository) {
        this.stockMovementRepository = stockMovementRepository;
        this.materialRepository = materialRepository;
        this.locationRepository = locationRepository;
        this.userRepository = userRepository;
    }

    public List<StockMovementDTO> findAll() {
        final List<StockMovement> stockMovements = stockMovementRepository.findAll(Sort.by("id"));
        return stockMovements.stream()
                .map(stockMovement -> mapToDTO(stockMovement, new StockMovementDTO()))
                .toList();
    }

    public StockMovementDTO get(final Integer id) {
        return stockMovementRepository.findById(id)
                .map(stockMovement -> mapToDTO(stockMovement, new StockMovementDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final StockMovementDTO stockMovementDTO) {
        final StockMovement stockMovement = new StockMovement();
        mapToEntity(stockMovementDTO, stockMovement);
        return stockMovementRepository.save(stockMovement).getId();
    }

    public void update(final Integer id, final StockMovementDTO stockMovementDTO) {
        final StockMovement stockMovement = stockMovementRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(stockMovementDTO, stockMovement);
        stockMovementRepository.save(stockMovement);
    }

    public void delete(final Integer id) {
        stockMovementRepository.deleteById(id);
    }

    private StockMovementDTO mapToDTO(final StockMovement stockMovement,
            final StockMovementDTO stockMovementDTO) {
        stockMovementDTO.setId(stockMovement.getId());
        stockMovementDTO.setCreatedAt(stockMovement.getCreatedAt());
        stockMovementDTO.setType(stockMovement.getType());
        stockMovementDTO.setQuantityChange(stockMovement.getQuantityChange());
        stockMovementDTO.setNewQuantity(stockMovement.getNewQuantity());
        stockMovementDTO.setTimestamp(stockMovement.getTimestamp());
        stockMovementDTO.setMaterial(stockMovement.getMaterial() == null ? null : stockMovement.getMaterial().getId());
        stockMovementDTO.setLocation(stockMovement.getLocation() == null ? null : stockMovement.getLocation().getId());
        stockMovementDTO.setUser(stockMovement.getUser() == null ? null : stockMovement.getUser().getId());
        return stockMovementDTO;
    }

    private StockMovement mapToEntity(final StockMovementDTO stockMovementDTO,
            final StockMovement stockMovement) {
        stockMovement.setCreatedAt(stockMovementDTO.getCreatedAt());
        stockMovement.setType(stockMovementDTO.getType());
        stockMovement.setQuantityChange(stockMovementDTO.getQuantityChange());
        stockMovement.setNewQuantity(stockMovementDTO.getNewQuantity());
        stockMovement.setTimestamp(stockMovementDTO.getTimestamp());
        final Material material = stockMovementDTO.getMaterial() == null ? null : materialRepository.findById(stockMovementDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        stockMovement.setMaterial(material);
        final Location location = stockMovementDTO.getLocation() == null ? null : locationRepository.findById(stockMovementDTO.getLocation())
                .orElseThrow(() -> new NotFoundException("location not found"));
        stockMovement.setLocation(location);
        final User user = stockMovementDTO.getUser() == null ? null : userRepository.findById(stockMovementDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        stockMovement.setUser(user);
        return stockMovement;
    }

}
