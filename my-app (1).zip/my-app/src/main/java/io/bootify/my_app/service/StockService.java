package io.bootify.my_app.service;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Stock;
import io.bootify.my_app.model.StockDTO;
import io.bootify.my_app.repos.LocationRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.StockRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class StockService {

    private final StockRepository stockRepository;
    private final MaterialRepository materialRepository;
    private final LocationRepository locationRepository;

    public StockService(final StockRepository stockRepository,
            final MaterialRepository materialRepository,
            final LocationRepository locationRepository) {
        this.stockRepository = stockRepository;
        this.materialRepository = materialRepository;
        this.locationRepository = locationRepository;
    }

    public List<StockDTO> findAll() {
        final List<Stock> stocks = stockRepository.findAll(Sort.by("id"));
        return stocks.stream()
                .map(stock -> mapToDTO(stock, new StockDTO()))
                .toList();
    }

    public StockDTO get(final Integer id) {
        return stockRepository.findById(id)
                .map(stock -> mapToDTO(stock, new StockDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final StockDTO stockDTO) {
        final Stock stock = new Stock();
        mapToEntity(stockDTO, stock);
        return stockRepository.save(stock).getId();
    }

    public void update(final Integer id, final StockDTO stockDTO) {
        final Stock stock = stockRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(stockDTO, stock);
        stockRepository.save(stock);
    }

    public void delete(final Integer id) {
        stockRepository.deleteById(id);
    }

    private StockDTO mapToDTO(final Stock stock, final StockDTO stockDTO) {
        stockDTO.setId(stock.getId());
        stockDTO.setCreatedAt(stock.getCreatedAt());
        stockDTO.setQuantity(stock.getQuantity());
        stockDTO.setMaterial(stock.getMaterial() == null ? null : stock.getMaterial().getId());
        stockDTO.setLocation(stock.getLocation() == null ? null : stock.getLocation().getId());
        return stockDTO;
    }

    private Stock mapToEntity(final StockDTO stockDTO, final Stock stock) {
        stock.setCreatedAt(stockDTO.getCreatedAt());
        stock.setQuantity(stockDTO.getQuantity());
        final Material material = stockDTO.getMaterial() == null ? null : materialRepository.findById(stockDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        stock.setMaterial(material);
        final Location location = stockDTO.getLocation() == null ? null : locationRepository.findById(stockDTO.getLocation())
                .orElseThrow(() -> new NotFoundException("location not found"));
        stock.setLocation(location);
        return stock;
    }

}
