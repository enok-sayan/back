package io.bootify.my_app.service;

import io.bootify.my_app.domain.ActivityLog;
import io.bootify.my_app.domain.Alert;
import io.bootify.my_app.domain.BorrowRequest;
import io.bootify.my_app.domain.MaintenanceRecord;
import io.bootify.my_app.domain.Message;
import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.domain.StockMovement;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.domain.UserRole;
import io.bootify.my_app.domain.UserType;
import io.bootify.my_app.model.UserDTO;
import io.bootify.my_app.repos.ActivityLogRepository;
import io.bootify.my_app.repos.AlertRepository;
import io.bootify.my_app.repos.BorrowRequestRepository;
import io.bootify.my_app.repos.MaintenanceRecordRepository;
import io.bootify.my_app.repos.MessageRepository;
import io.bootify.my_app.repos.ReceptionRepository;
import io.bootify.my_app.repos.ShipmentRepository;
import io.bootify.my_app.repos.StockMovementRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.repos.UserRoleRepository;
import io.bootify.my_app.repos.UserTypeRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserTypeRepository userTypeRepository;
    private final UserRoleRepository userRoleRepository;
    private final StockMovementRepository stockMovementRepository;
    private final ShipmentRepository shipmentRepository;
    private final ReceptionRepository receptionRepository;
    private final MaintenanceRecordRepository maintenanceRecordRepository;
    private final BorrowRequestRepository borrowRequestRepository;
    private final AlertRepository alertRepository;
    private final ActivityLogRepository activityLogRepository;
    private final MessageRepository messageRepository;

    public UserService(final UserRepository userRepository,
            final UserTypeRepository userTypeRepository,
            final UserRoleRepository userRoleRepository,
            final StockMovementRepository stockMovementRepository,
            final ShipmentRepository shipmentRepository,
            final ReceptionRepository receptionRepository,
            final MaintenanceRecordRepository maintenanceRecordRepository,
            final BorrowRequestRepository borrowRequestRepository,
            final AlertRepository alertRepository,
            final ActivityLogRepository activityLogRepository,
            final MessageRepository messageRepository) {
        this.userRepository = userRepository;
        this.userTypeRepository = userTypeRepository;
        this.userRoleRepository = userRoleRepository;
        this.stockMovementRepository = stockMovementRepository;
        this.shipmentRepository = shipmentRepository;
        this.receptionRepository = receptionRepository;
        this.maintenanceRecordRepository = maintenanceRecordRepository;
        this.borrowRequestRepository = borrowRequestRepository;
        this.alertRepository = alertRepository;
        this.activityLogRepository = activityLogRepository;
        this.messageRepository = messageRepository;
    }

    public List<UserDTO> findAll() {
        final List<User> users = userRepository.findAll(Sort.by("id"));
        return users.stream()
                .map(user -> mapToDTO(user, new UserDTO()))
                .toList();
    }

    public UserDTO get(final Integer id) {
        return userRepository.findById(id)
                .map(user -> mapToDTO(user, new UserDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final UserDTO userDTO) {
        final User user = new User();
        mapToEntity(userDTO, user);
        return userRepository.save(user).getId();
    }

    public void update(final Integer id, final UserDTO userDTO) {
        final User user = userRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(userDTO, user);
        userRepository.save(user);
    }

    public void delete(final Integer id) {
        userRepository.deleteById(id);
    }

    private UserDTO mapToDTO(final User user, final UserDTO userDTO) {
        userDTO.setId(user.getId());
        userDTO.setCreatedAt(user.getCreatedAt());
        userDTO.setName(user.getName());
        userDTO.setEmail(user.getEmail());
        userDTO.setPassword(user.getPassword());
        userDTO.setUsername(user.getUsername());
        userDTO.setFirstName(user.getFirstName());
        userDTO.setLastName(user.getLastName());
        userDTO.setPhone(user.getPhone());
        userDTO.setDateOfBirth(user.getDateOfBirth());
        userDTO.setEmailVerified(user.getEmailVerified());
        userDTO.setUserType(user.getUserType() == null ? null : user.getUserType().getId());
        return userDTO;
    }

    private User mapToEntity(final UserDTO userDTO, final User user) {
        user.setCreatedAt(userDTO.getCreatedAt());
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPassword(userDTO.getPassword());
        user.setUsername(userDTO.getUsername());
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        user.setPhone(userDTO.getPhone());
        user.setDateOfBirth(userDTO.getDateOfBirth());
        user.setEmailVerified(userDTO.getEmailVerified());
        final UserType userType = userDTO.getUserType() == null ? null : userTypeRepository.findById(userDTO.getUserType())
                .orElseThrow(() -> new NotFoundException("userType not found"));
        user.setUserType(userType);
        return user;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final User user = userRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final UserRole userUserRole = userRoleRepository.findFirstByUser(user);
        if (userUserRole != null) {
            referencedWarning.setKey("user.userRole.user.referenced");
            referencedWarning.addParam(userUserRole.getId());
            return referencedWarning;
        }
        final StockMovement userStockMovement = stockMovementRepository.findFirstByUser(user);
        if (userStockMovement != null) {
            referencedWarning.setKey("user.stockMovement.user.referenced");
            referencedWarning.addParam(userStockMovement.getId());
            return referencedWarning;
        }
        final Shipment shippedByUserShipment = shipmentRepository.findFirstByShippedByUser(user);
        if (shippedByUserShipment != null) {
            referencedWarning.setKey("user.shipment.shippedByUser.referenced");
            referencedWarning.addParam(shippedByUserShipment.getId());
            return referencedWarning;
        }
        final Reception receivedByUserReception = receptionRepository.findFirstByReceivedByUser(user);
        if (receivedByUserReception != null) {
            referencedWarning.setKey("user.reception.receivedByUser.referenced");
            referencedWarning.addParam(receivedByUserReception.getId());
            return referencedWarning;
        }
        final MaintenanceRecord technicianMaintenanceRecord = maintenanceRecordRepository.findFirstByTechnician(user);
        if (technicianMaintenanceRecord != null) {
            referencedWarning.setKey("user.maintenanceRecord.technician.referenced");
            referencedWarning.addParam(technicianMaintenanceRecord.getId());
            return referencedWarning;
        }
        final BorrowRequest userBorrowRequest = borrowRequestRepository.findFirstByUser(user);
        if (userBorrowRequest != null) {
            referencedWarning.setKey("user.borrowRequest.user.referenced");
            referencedWarning.addParam(userBorrowRequest.getId());
            return referencedWarning;
        }
        final Alert userAlert = alertRepository.findFirstByUser(user);
        if (userAlert != null) {
            referencedWarning.setKey("user.alert.user.referenced");
            referencedWarning.addParam(userAlert.getId());
            return referencedWarning;
        }
        final ActivityLog userActivityLog = activityLogRepository.findFirstByUser(user);
        if (userActivityLog != null) {
            referencedWarning.setKey("user.activityLog.user.referenced");
            referencedWarning.addParam(userActivityLog.getId());
            return referencedWarning;
        }
        final Message senderMessage = messageRepository.findFirstBySender(user);
        if (senderMessage != null) {
            referencedWarning.setKey("user.message.sender.referenced");
            referencedWarning.addParam(senderMessage.getId());
            return referencedWarning;
        }
        final Message receiverMessage = messageRepository.findFirstByReceiver(user);
        if (receiverMessage != null) {
            referencedWarning.setKey("user.message.receiver.referenced");
            referencedWarning.addParam(receiverMessage.getId());
            return referencedWarning;
        }
        return null;
    }

}
