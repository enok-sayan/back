package io.bootify.my_app.service;

import io.bootify.my_app.domain.Manufacturer;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.model.ManufacturerDTO;
import io.bootify.my_app.repos.ManufacturerRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ManufacturerService {

    private final ManufacturerRepository manufacturerRepository;
    private final MaterialRepository materialRepository;

    public ManufacturerService(final ManufacturerRepository manufacturerRepository,
            final MaterialRepository materialRepository) {
        this.manufacturerRepository = manufacturerRepository;
        this.materialRepository = materialRepository;
    }

    public List<ManufacturerDTO> findAll() {
        final List<Manufacturer> manufacturers = manufacturerRepository.findAll(Sort.by("id"));
        return manufacturers.stream()
                .map(manufacturer -> mapToDTO(manufacturer, new ManufacturerDTO()))
                .toList();
    }

    public ManufacturerDTO get(final Integer id) {
        return manufacturerRepository.findById(id)
                .map(manufacturer -> mapToDTO(manufacturer, new ManufacturerDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ManufacturerDTO manufacturerDTO) {
        final Manufacturer manufacturer = new Manufacturer();
        mapToEntity(manufacturerDTO, manufacturer);
        return manufacturerRepository.save(manufacturer).getId();
    }

    public void update(final Integer id, final ManufacturerDTO manufacturerDTO) {
        final Manufacturer manufacturer = manufacturerRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(manufacturerDTO, manufacturer);
        manufacturerRepository.save(manufacturer);
    }

    public void delete(final Integer id) {
        manufacturerRepository.deleteById(id);
    }

    private ManufacturerDTO mapToDTO(final Manufacturer manufacturer,
            final ManufacturerDTO manufacturerDTO) {
        manufacturerDTO.setId(manufacturer.getId());
        manufacturerDTO.setCreatedAt(manufacturer.getCreatedAt());
        manufacturerDTO.setName(manufacturer.getName());
        manufacturerDTO.setCountry(manufacturer.getCountry());
        return manufacturerDTO;
    }

    private Manufacturer mapToEntity(final ManufacturerDTO manufacturerDTO,
            final Manufacturer manufacturer) {
        manufacturer.setCreatedAt(manufacturerDTO.getCreatedAt());
        manufacturer.setName(manufacturerDTO.getName());
        manufacturer.setCountry(manufacturerDTO.getCountry());
        return manufacturer;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Manufacturer manufacturer = manufacturerRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Material manufacturerMaterial = materialRepository.findFirstByManufacturer(manufacturer);
        if (manufacturerMaterial != null) {
            referencedWarning.setKey("manufacturer.material.manufacturer.referenced");
            referencedWarning.addParam(manufacturerMaterial.getId());
            return referencedWarning;
        }
        return null;
    }

}
