package io.bootify.my_app.rest;

import io.bootify.my_app.model.ManufacturerDTO;
import io.bootify.my_app.service.ManufacturerService;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/manufacturers", produces = MediaType.APPLICATION_JSON_VALUE)
public class ManufacturerResource {

    private final ManufacturerService manufacturerService;

    public ManufacturerResource(final ManufacturerService manufacturerService) {
        this.manufacturerService = manufacturerService;
    }

    @GetMapping
    public ResponseEntity<List<ManufacturerDTO>> getAllManufacturers() {
        return ResponseEntity.ok(manufacturerService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ManufacturerDTO> getManufacturer(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(manufacturerService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createManufacturer(
            @RequestBody @Valid final ManufacturerDTO manufacturerDTO) {
        final Integer createdId = manufacturerService.create(manufacturerDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateManufacturer(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ManufacturerDTO manufacturerDTO) {
        manufacturerService.update(id, manufacturerDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteManufacturer(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = manufacturerService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        manufacturerService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
