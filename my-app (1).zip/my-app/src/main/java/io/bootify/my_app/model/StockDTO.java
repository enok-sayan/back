package io.bootify.my_app.model;

import java.time.OffsetDateTime;


public class StockDTO {

    private Integer id;
    private OffsetDateTime createdAt;
    private Integer quantity;
    private Integer material;
    private Integer location;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(final Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

    public Integer getLocation() {
        return location;
    }

    public void setLocation(final Integer location) {
        this.location = location;
    }

}
