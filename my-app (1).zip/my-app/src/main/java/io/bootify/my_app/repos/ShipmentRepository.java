package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Client;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ShipmentRepository extends JpaRepository<Shipment, Integer> {

    Shipment findFirstByClient(Client client);

    Shipment findFirstByShippedByUser(User user);

}
