package io.bootify.my_app.service;

import io.bootify.my_app.domain.Alert;
import io.bootify.my_app.domain.BorrowRequest;
import io.bootify.my_app.domain.Category;
import io.bootify.my_app.domain.Document;
import io.bootify.my_app.domain.MaintenanceRecord;
import io.bootify.my_app.domain.Manufacturer;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.MaterialStatus;
import io.bootify.my_app.domain.ReceptionItem;
import io.bootify.my_app.domain.ShipmentItem;
import io.bootify.my_app.domain.Stock;
import io.bootify.my_app.domain.StockMovement;
import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.model.MaterialDTO;
import io.bootify.my_app.repos.AlertRepository;
import io.bootify.my_app.repos.BorrowRequestRepository;
import io.bootify.my_app.repos.CategoryRepository;
import io.bootify.my_app.repos.DocumentRepository;
import io.bootify.my_app.repos.MaintenanceRecordRepository;
import io.bootify.my_app.repos.ManufacturerRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.MaterialStatusRepository;
import io.bootify.my_app.repos.ReceptionItemRepository;
import io.bootify.my_app.repos.ShipmentItemRepository;
import io.bootify.my_app.repos.StockMovementRepository;
import io.bootify.my_app.repos.StockRepository;
import io.bootify.my_app.repos.SupplierRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class MaterialService {

    private final MaterialRepository materialRepository;
    private final CategoryRepository categoryRepository;
    private final MaterialStatusRepository materialStatusRepository;
    private final SupplierRepository supplierRepository;
    private final ManufacturerRepository manufacturerRepository;
    private final StockRepository stockRepository;
    private final StockMovementRepository stockMovementRepository;
    private final ShipmentItemRepository shipmentItemRepository;
    private final ReceptionItemRepository receptionItemRepository;
    private final MaintenanceRecordRepository maintenanceRecordRepository;
    private final DocumentRepository documentRepository;
    private final BorrowRequestRepository borrowRequestRepository;
    private final AlertRepository alertRepository;

    public MaterialService(final MaterialRepository materialRepository,
            final CategoryRepository categoryRepository,
            final MaterialStatusRepository materialStatusRepository,
            final SupplierRepository supplierRepository,
            final ManufacturerRepository manufacturerRepository,
            final StockRepository stockRepository,
            final StockMovementRepository stockMovementRepository,
            final ShipmentItemRepository shipmentItemRepository,
            final ReceptionItemRepository receptionItemRepository,
            final MaintenanceRecordRepository maintenanceRecordRepository,
            final DocumentRepository documentRepository,
            final BorrowRequestRepository borrowRequestRepository,
            final AlertRepository alertRepository) {
        this.materialRepository = materialRepository;
        this.categoryRepository = categoryRepository;
        this.materialStatusRepository = materialStatusRepository;
        this.supplierRepository = supplierRepository;
        this.manufacturerRepository = manufacturerRepository;
        this.stockRepository = stockRepository;
        this.stockMovementRepository = stockMovementRepository;
        this.shipmentItemRepository = shipmentItemRepository;
        this.receptionItemRepository = receptionItemRepository;
        this.maintenanceRecordRepository = maintenanceRecordRepository;
        this.documentRepository = documentRepository;
        this.borrowRequestRepository = borrowRequestRepository;
        this.alertRepository = alertRepository;
    }

    public List<MaterialDTO> findAll() {
        final List<Material> materials = materialRepository.findAll(Sort.by("id"));
        return materials.stream()
                .map(material -> mapToDTO(material, new MaterialDTO()))
                .toList();
    }

    public MaterialDTO get(final Integer id) {
        return materialRepository.findById(id)
                .map(material -> mapToDTO(material, new MaterialDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final MaterialDTO materialDTO) {
        final Material material = new Material();
        mapToEntity(materialDTO, material);
        return materialRepository.save(material).getId();
    }

    public void update(final Integer id, final MaterialDTO materialDTO) {
        final Material material = materialRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(materialDTO, material);
        materialRepository.save(material);
    }

    public void delete(final Integer id) {
        materialRepository.deleteById(id);
    }

    private MaterialDTO mapToDTO(final Material material, final MaterialDTO materialDTO) {
        materialDTO.setId(material.getId());
        materialDTO.setCreatedAt(material.getCreatedAt());
        materialDTO.setName(material.getName());
        materialDTO.setDescription(material.getDescription());
        materialDTO.setSerialNumber(material.getSerialNumber());
        materialDTO.setQuantity(material.getQuantity());
        materialDTO.setAvailable(material.getAvailable());
        materialDTO.setPurchaseDate(material.getPurchaseDate());
        materialDTO.setPurchasePrice(material.getPurchasePrice());
        materialDTO.setImageUrl(material.getImageUrl());
        materialDTO.setMinStockLevel(material.getMinStockLevel());
        materialDTO.setCategory(material.getCategory() == null ? null : material.getCategory().getId());
        materialDTO.setMaterialStatus(material.getMaterialStatus() == null ? null : material.getMaterialStatus().getId());
        materialDTO.setSupplier(material.getSupplier() == null ? null : material.getSupplier().getId());
        materialDTO.setManufacturer(material.getManufacturer() == null ? null : material.getManufacturer().getId());
        return materialDTO;
    }

    private Material mapToEntity(final MaterialDTO materialDTO, final Material material) {
        material.setCreatedAt(materialDTO.getCreatedAt());
        material.setName(materialDTO.getName());
        material.setDescription(materialDTO.getDescription());
        material.setSerialNumber(materialDTO.getSerialNumber());
        material.setQuantity(materialDTO.getQuantity());
        material.setAvailable(materialDTO.getAvailable());
        material.setPurchaseDate(materialDTO.getPurchaseDate());
        material.setPurchasePrice(materialDTO.getPurchasePrice());
        material.setImageUrl(materialDTO.getImageUrl());
        material.setMinStockLevel(materialDTO.getMinStockLevel());
        final Category category = materialDTO.getCategory() == null ? null : categoryRepository.findById(materialDTO.getCategory())
                .orElseThrow(() -> new NotFoundException("category not found"));
        material.setCategory(category);
        final MaterialStatus materialStatus = materialDTO.getMaterialStatus() == null ? null : materialStatusRepository.findById(materialDTO.getMaterialStatus())
                .orElseThrow(() -> new NotFoundException("materialStatus not found"));
        material.setMaterialStatus(materialStatus);
        final Supplier supplier = materialDTO.getSupplier() == null ? null : supplierRepository.findById(materialDTO.getSupplier())
                .orElseThrow(() -> new NotFoundException("supplier not found"));
        material.setSupplier(supplier);
        final Manufacturer manufacturer = materialDTO.getManufacturer() == null ? null : manufacturerRepository.findById(materialDTO.getManufacturer())
                .orElseThrow(() -> new NotFoundException("manufacturer not found"));
        material.setManufacturer(manufacturer);
        return material;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Material material = materialRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Stock materialStock = stockRepository.findFirstByMaterial(material);
        if (materialStock != null) {
            referencedWarning.setKey("material.stock.material.referenced");
            referencedWarning.addParam(materialStock.getId());
            return referencedWarning;
        }
        final StockMovement materialStockMovement = stockMovementRepository.findFirstByMaterial(material);
        if (materialStockMovement != null) {
            referencedWarning.setKey("material.stockMovement.material.referenced");
            referencedWarning.addParam(materialStockMovement.getId());
            return referencedWarning;
        }
        final ShipmentItem materialShipmentItem = shipmentItemRepository.findFirstByMaterial(material);
        if (materialShipmentItem != null) {
            referencedWarning.setKey("material.shipmentItem.material.referenced");
            referencedWarning.addParam(materialShipmentItem.getId());
            return referencedWarning;
        }
        final ReceptionItem materialReceptionItem = receptionItemRepository.findFirstByMaterial(material);
        if (materialReceptionItem != null) {
            referencedWarning.setKey("material.receptionItem.material.referenced");
            referencedWarning.addParam(materialReceptionItem.getId());
            return referencedWarning;
        }
        final MaintenanceRecord materialMaintenanceRecord = maintenanceRecordRepository.findFirstByMaterial(material);
        if (materialMaintenanceRecord != null) {
            referencedWarning.setKey("material.maintenanceRecord.material.referenced");
            referencedWarning.addParam(materialMaintenanceRecord.getId());
            return referencedWarning;
        }
        final Document materialDocument = documentRepository.findFirstByMaterial(material);
        if (materialDocument != null) {
            referencedWarning.setKey("material.document.material.referenced");
            referencedWarning.addParam(materialDocument.getId());
            return referencedWarning;
        }
        final BorrowRequest materialBorrowRequest = borrowRequestRepository.findFirstByMaterial(material);
        if (materialBorrowRequest != null) {
            referencedWarning.setKey("material.borrowRequest.material.referenced");
            referencedWarning.addParam(materialBorrowRequest.getId());
            return referencedWarning;
        }
        final Alert materialAlert = alertRepository.findFirstByMaterial(material);
        if (materialAlert != null) {
            referencedWarning.setKey("material.alert.material.referenced");
            referencedWarning.addParam(materialAlert.getId());
            return referencedWarning;
        }
        return null;
    }

}
