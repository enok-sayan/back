package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Role;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.domain.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRoleRepository extends JpaRepository<UserRole, Integer> {

    UserRole findFirstByUser(User user);

    UserRole findFirstByRole(Role role);

}
