package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.domain.ShipmentItem;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ShipmentItemRepository extends JpaRepository<ShipmentItem, Integer> {

    ShipmentItem findFirstByShipment(Shipment shipment);

    ShipmentItem findFirstByMaterial(Material material);

}
