package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReceptionRepository extends JpaRepository<Reception, Integer> {

    Reception findFirstBySupplier(Supplier supplier);

    Reception findFirstByReceivedByUser(User user);

}
