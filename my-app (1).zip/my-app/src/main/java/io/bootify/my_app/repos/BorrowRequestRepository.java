package io.bootify.my_app.repos;

import io.bootify.my_app.domain.BorrowRequest;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BorrowRequestRepository extends JpaRepository<BorrowRequest, Integer> {

    BorrowRequest findFirstByUser(User user);

    BorrowRequest findFirstByMaterial(Material material);

}
