package io.bootify.my_app.rest;

import io.bootify.my_app.model.UserTypeDTO;
import io.bootify.my_app.service.UserTypeService;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/userTypes", produces = MediaType.APPLICATION_JSON_VALUE)
public class UserTypeResource {

    private final UserTypeService userTypeService;

    public UserTypeResource(final UserTypeService userTypeService) {
        this.userTypeService = userTypeService;
    }

    @GetMapping
    public ResponseEntity<List<UserTypeDTO>> getAllUserTypes() {
        return ResponseEntity.ok(userTypeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserTypeDTO> getUserType(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(userTypeService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createUserType(
            @RequestBody @Valid final UserTypeDTO userTypeDTO) {
        final Integer createdId = userTypeService.create(userTypeDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateUserType(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final UserTypeDTO userTypeDTO) {
        userTypeService.update(id, userTypeDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUserType(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = userTypeService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        userTypeService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
