package io.bootify.my_app.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Set;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Entity
@Table(name = "Materials")
@EntityListeners(AuditingEntityListener.class)
public class Material {

    @Id
    @Column(nullable = false, updatable = false)
    @SequenceGenerator(
            name = "primary_sequence",
            sequenceName = "primary_sequence",
            allocationSize = 1,
            initialValue = 10000
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "primary_sequence"
    )
    private Integer id;

    @Column
    private OffsetDateTime createdAt;

    @Column(nullable = false, columnDefinition = "text")
    private String name;

    @Column(columnDefinition = "text")
    private String description;

    @Column(columnDefinition = "text")
    private String serialNumber;

    @Column
    private Integer quantity;

    @Column
    private Boolean available;

    @Column
    private LocalDate purchaseDate;

    @Column(precision = 10, scale = 2)
    private BigDecimal purchasePrice;

    @Column(columnDefinition = "text")
    private String imageUrl;

    @Column
    private Integer minStockLevel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "material_status_id")
    private MaterialStatus materialStatus;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "supplier_id")
    private Supplier supplier;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manufacturer_id")
    private Manufacturer manufacturer;

    @OneToMany(mappedBy = "material")
    private Set<Stock> materialStocks;

    @OneToMany(mappedBy = "material")
    private Set<StockMovement> materialStockMovements;

    @OneToMany(mappedBy = "material")
    private Set<ShipmentItem> materialShipmentItems;

    @OneToMany(mappedBy = "material")
    private Set<ReceptionItem> materialReceptionItems;

    @OneToMany(mappedBy = "material")
    private Set<MaintenanceRecord> materialMaintenanceRecords;

    @OneToMany(mappedBy = "material")
    private Set<Document> materialDocuments;

    @OneToMany(mappedBy = "material")
    private Set<BorrowRequest> materialBorrowRequests;

    @OneToMany(mappedBy = "material")
    private Set<Alert> materialAlerts;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private OffsetDateTime dateCreated;

    @LastModifiedDate
    @Column(nullable = false)
    private OffsetDateTime lastUpdated;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(final String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(final Integer quantity) {
        this.quantity = quantity;
    }

    public Boolean getAvailable() {
        return available;
    }

    public void setAvailable(final Boolean available) {
        this.available = available;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(final LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(final BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(final String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Integer getMinStockLevel() {
        return minStockLevel;
    }

    public void setMinStockLevel(final Integer minStockLevel) {
        this.minStockLevel = minStockLevel;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(final Category category) {
        this.category = category;
    }

    public MaterialStatus getMaterialStatus() {
        return materialStatus;
    }

    public void setMaterialStatus(final MaterialStatus materialStatus) {
        this.materialStatus = materialStatus;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(final Supplier supplier) {
        this.supplier = supplier;
    }

    public Manufacturer getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(final Manufacturer manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Set<Stock> getMaterialStocks() {
        return materialStocks;
    }

    public void setMaterialStocks(final Set<Stock> materialStocks) {
        this.materialStocks = materialStocks;
    }

    public Set<StockMovement> getMaterialStockMovements() {
        return materialStockMovements;
    }

    public void setMaterialStockMovements(final Set<StockMovement> materialStockMovements) {
        this.materialStockMovements = materialStockMovements;
    }

    public Set<ShipmentItem> getMaterialShipmentItems() {
        return materialShipmentItems;
    }

    public void setMaterialShipmentItems(final Set<ShipmentItem> materialShipmentItems) {
        this.materialShipmentItems = materialShipmentItems;
    }

    public Set<ReceptionItem> getMaterialReceptionItems() {
        return materialReceptionItems;
    }

    public void setMaterialReceptionItems(final Set<ReceptionItem> materialReceptionItems) {
        this.materialReceptionItems = materialReceptionItems;
    }

    public Set<MaintenanceRecord> getMaterialMaintenanceRecords() {
        return materialMaintenanceRecords;
    }

    public void setMaterialMaintenanceRecords(
            final Set<MaintenanceRecord> materialMaintenanceRecords) {
        this.materialMaintenanceRecords = materialMaintenanceRecords;
    }

    public Set<Document> getMaterialDocuments() {
        return materialDocuments;
    }

    public void setMaterialDocuments(final Set<Document> materialDocuments) {
        this.materialDocuments = materialDocuments;
    }

    public Set<BorrowRequest> getMaterialBorrowRequests() {
        return materialBorrowRequests;
    }

    public void setMaterialBorrowRequests(final Set<BorrowRequest> materialBorrowRequests) {
        this.materialBorrowRequests = materialBorrowRequests;
    }

    public Set<Alert> getMaterialAlerts() {
        return materialAlerts;
    }

    public void setMaterialAlerts(final Set<Alert> materialAlerts) {
        this.materialAlerts = materialAlerts;
    }

    public OffsetDateTime getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(final OffsetDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }

    public OffsetDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(final OffsetDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

}
