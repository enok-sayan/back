package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Category;
import io.bootify.my_app.domain.Manufacturer;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.MaterialStatus;
import io.bootify.my_app.domain.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MaterialRepository extends JpaRepository<Material, Integer> {

    Material findFirstByCategory(Category category);

    Material findFirstByMaterialStatus(MaterialStatus materialStatus);

    Material findFirstBySupplier(Supplier supplier);

    Material findFirstByManufacturer(Manufacturer manufacturer);

}
