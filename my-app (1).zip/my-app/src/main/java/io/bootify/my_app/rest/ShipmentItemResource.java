package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.model.ShipmentItemDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.ShipmentRepository;
import io.bootify.my_app.service.ShipmentItemService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/shipmentItems", produces = MediaType.APPLICATION_JSON_VALUE)
public class ShipmentItemResource {

    private final ShipmentItemService shipmentItemService;
    private final ShipmentRepository shipmentRepository;
    private final MaterialRepository materialRepository;

    public ShipmentItemResource(final ShipmentItemService shipmentItemService,
            final ShipmentRepository shipmentRepository,
            final MaterialRepository materialRepository) {
        this.shipmentItemService = shipmentItemService;
        this.shipmentRepository = shipmentRepository;
        this.materialRepository = materialRepository;
    }

    @GetMapping
    public ResponseEntity<List<ShipmentItemDTO>> getAllShipmentItems() {
        return ResponseEntity.ok(shipmentItemService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ShipmentItemDTO> getShipmentItem(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(shipmentItemService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createShipmentItem(
            @RequestBody @Valid final ShipmentItemDTO shipmentItemDTO) {
        final Integer createdId = shipmentItemService.create(shipmentItemDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateShipmentItem(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ShipmentItemDTO shipmentItemDTO) {
        shipmentItemService.update(id, shipmentItemDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteShipmentItem(@PathVariable(name = "id") final Integer id) {
        shipmentItemService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/shipmentValues")
    public ResponseEntity<Map<Integer, Integer>> getShipmentValues() {
        return ResponseEntity.ok(shipmentRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Shipment::getId, Shipment::getId)));
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

}
