package io.bootify.my_app.model;

import jakarta.validation.constraints.NotNull;
import java.time.OffsetDateTime;


public class ShipmentItemDTO {

    private Integer id;

    private OffsetDateTime createdAt;

    @NotNull
    private Integer quantityShipped;

    private Integer shipment;

    private Integer material;

    public Integer getId() {
        return id;
    }

    public void setId(final Integer id) {
        this.id = id;
    }

    public OffsetDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(final OffsetDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Integer getQuantityShipped() {
        return quantityShipped;
    }

    public void setQuantityShipped(final Integer quantityShipped) {
        this.quantityShipped = quantityShipped;
    }

    public Integer getShipment() {
        return shipment;
    }

    public void setShipment(final Integer shipment) {
        this.shipment = shipment;
    }

    public Integer getMaterial() {
        return material;
    }

    public void setMaterial(final Integer material) {
        this.material = material;
    }

}
