package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.model.StockDTO;
import io.bootify.my_app.repos.LocationRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.service.StockService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/stocks", produces = MediaType.APPLICATION_JSON_VALUE)
public class StockResource {

    private final StockService stockService;
    private final MaterialRepository materialRepository;
    private final LocationRepository locationRepository;

    public StockResource(final StockService stockService,
            final MaterialRepository materialRepository,
            final LocationRepository locationRepository) {
        this.stockService = stockService;
        this.materialRepository = materialRepository;
        this.locationRepository = locationRepository;
    }

    @GetMapping
    public ResponseEntity<List<StockDTO>> getAllStocks() {
        return ResponseEntity.ok(stockService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<StockDTO> getStock(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(stockService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createStock(@RequestBody @Valid final StockDTO stockDTO) {
        final Integer createdId = stockService.create(stockDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateStock(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final StockDTO stockDTO) {
        stockService.update(id, stockDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStock(@PathVariable(name = "id") final Integer id) {
        stockService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

    @GetMapping("/locationValues")
    public ResponseEntity<Map<Integer, Integer>> getLocationValues() {
        return ResponseEntity.ok(locationRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Location::getId, Location::getId)));
    }

}
