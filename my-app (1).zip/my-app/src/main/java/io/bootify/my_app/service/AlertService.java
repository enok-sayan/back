package io.bootify.my_app.service;

import io.bootify.my_app.domain.Alert;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.AlertDTO;
import io.bootify.my_app.repos.AlertRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class AlertService {

    private final AlertRepository alertRepository;
    private final UserRepository userRepository;
    private final MaterialRepository materialRepository;

    public AlertService(final AlertRepository alertRepository, final UserRepository userRepository,
            final MaterialRepository materialRepository) {
        this.alertRepository = alertRepository;
        this.userRepository = userRepository;
        this.materialRepository = materialRepository;
    }

    public List<AlertDTO> findAll() {
        final List<Alert> alerts = alertRepository.findAll(Sort.by("id"));
        return alerts.stream()
                .map(alert -> mapToDTO(alert, new AlertDTO()))
                .toList();
    }

    public AlertDTO get(final Integer id) {
        return alertRepository.findById(id)
                .map(alert -> mapToDTO(alert, new AlertDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final AlertDTO alertDTO) {
        final Alert alert = new Alert();
        mapToEntity(alertDTO, alert);
        return alertRepository.save(alert).getId();
    }

    public void update(final Integer id, final AlertDTO alertDTO) {
        final Alert alert = alertRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(alertDTO, alert);
        alertRepository.save(alert);
    }

    public void delete(final Integer id) {
        alertRepository.deleteById(id);
    }

    private AlertDTO mapToDTO(final Alert alert, final AlertDTO alertDTO) {
        alertDTO.setId(alert.getId());
        alertDTO.setCreatedAt(alert.getCreatedAt());
        alertDTO.setAlertType(alert.getAlertType());
        alertDTO.setMessage(alert.getMessage());
        alertDTO.setTimestamp(alert.getTimestamp());
        alertDTO.setIsRead(alert.getIsRead());
        alertDTO.setUser(alert.getUser() == null ? null : alert.getUser().getId());
        alertDTO.setMaterial(alert.getMaterial() == null ? null : alert.getMaterial().getId());
        return alertDTO;
    }

    private Alert mapToEntity(final AlertDTO alertDTO, final Alert alert) {
        alert.setCreatedAt(alertDTO.getCreatedAt());
        alert.setAlertType(alertDTO.getAlertType());
        alert.setMessage(alertDTO.getMessage());
        alert.setTimestamp(alertDTO.getTimestamp());
        alert.setIsRead(alertDTO.getIsRead());
        final User user = alertDTO.getUser() == null ? null : userRepository.findById(alertDTO.getUser())
                .orElseThrow(() -> new NotFoundException("user not found"));
        alert.setUser(user);
        final Material material = alertDTO.getMaterial() == null ? null : materialRepository.findById(alertDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        alert.setMaterial(material);
        return alert;
    }

}
