package io.bootify.my_app.service;

import io.bootify.my_app.domain.Location;
import io.bootify.my_app.domain.Stock;
import io.bootify.my_app.domain.StockMovement;
import io.bootify.my_app.model.LocationDTO;
import io.bootify.my_app.repos.LocationRepository;
import io.bootify.my_app.repos.StockMovementRepository;
import io.bootify.my_app.repos.StockRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class LocationService {

    private final LocationRepository locationRepository;
    private final StockRepository stockRepository;
    private final StockMovementRepository stockMovementRepository;

    public LocationService(final LocationRepository locationRepository,
            final StockRepository stockRepository,
            final StockMovementRepository stockMovementRepository) {
        this.locationRepository = locationRepository;
        this.stockRepository = stockRepository;
        this.stockMovementRepository = stockMovementRepository;
    }

    public List<LocationDTO> findAll() {
        final List<Location> locations = locationRepository.findAll(Sort.by("id"));
        return locations.stream()
                .map(location -> mapToDTO(location, new LocationDTO()))
                .toList();
    }

    public LocationDTO get(final Integer id) {
        return locationRepository.findById(id)
                .map(location -> mapToDTO(location, new LocationDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final LocationDTO locationDTO) {
        final Location location = new Location();
        mapToEntity(locationDTO, location);
        return locationRepository.save(location).getId();
    }

    public void update(final Integer id, final LocationDTO locationDTO) {
        final Location location = locationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(locationDTO, location);
        locationRepository.save(location);
    }

    public void delete(final Integer id) {
        locationRepository.deleteById(id);
    }

    private LocationDTO mapToDTO(final Location location, final LocationDTO locationDTO) {
        locationDTO.setId(location.getId());
        locationDTO.setCreatedAt(location.getCreatedAt());
        locationDTO.setName(location.getName());
        locationDTO.setDescription(location.getDescription());
        return locationDTO;
    }

    private Location mapToEntity(final LocationDTO locationDTO, final Location location) {
        location.setCreatedAt(locationDTO.getCreatedAt());
        location.setName(locationDTO.getName());
        location.setDescription(locationDTO.getDescription());
        return location;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Location location = locationRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Stock locationStock = stockRepository.findFirstByLocation(location);
        if (locationStock != null) {
            referencedWarning.setKey("location.stock.location.referenced");
            referencedWarning.addParam(locationStock.getId());
            return referencedWarning;
        }
        final StockMovement locationStockMovement = stockMovementRepository.findFirstByLocation(location);
        if (locationStockMovement != null) {
            referencedWarning.setKey("location.stockMovement.location.referenced");
            referencedWarning.addParam(locationStockMovement.getId());
            return referencedWarning;
        }
        return null;
    }

}
