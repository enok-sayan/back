package io.bootify.my_app.service;

import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.ReceptionItem;
import io.bootify.my_app.domain.Supplier;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ReceptionDTO;
import io.bootify.my_app.repos.ReceptionItemRepository;
import io.bootify.my_app.repos.ReceptionRepository;
import io.bootify.my_app.repos.SupplierRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ReceptionService {

    private final ReceptionRepository receptionRepository;
    private final SupplierRepository supplierRepository;
    private final UserRepository userRepository;
    private final ReceptionItemRepository receptionItemRepository;

    public ReceptionService(final ReceptionRepository receptionRepository,
            final SupplierRepository supplierRepository, final UserRepository userRepository,
            final ReceptionItemRepository receptionItemRepository) {
        this.receptionRepository = receptionRepository;
        this.supplierRepository = supplierRepository;
        this.userRepository = userRepository;
        this.receptionItemRepository = receptionItemRepository;
    }

    public List<ReceptionDTO> findAll() {
        final List<Reception> receptions = receptionRepository.findAll(Sort.by("id"));
        return receptions.stream()
                .map(reception -> mapToDTO(reception, new ReceptionDTO()))
                .toList();
    }

    public ReceptionDTO get(final Integer id) {
        return receptionRepository.findById(id)
                .map(reception -> mapToDTO(reception, new ReceptionDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ReceptionDTO receptionDTO) {
        final Reception reception = new Reception();
        mapToEntity(receptionDTO, reception);
        return receptionRepository.save(reception).getId();
    }

    public void update(final Integer id, final ReceptionDTO receptionDTO) {
        final Reception reception = receptionRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(receptionDTO, reception);
        receptionRepository.save(reception);
    }

    public void delete(final Integer id) {
        receptionRepository.deleteById(id);
    }

    private ReceptionDTO mapToDTO(final Reception reception, final ReceptionDTO receptionDTO) {
        receptionDTO.setId(reception.getId());
        receptionDTO.setCreatedAt(reception.getCreatedAt());
        receptionDTO.setReceptionDate(reception.getReceptionDate());
        receptionDTO.setStatus(reception.getStatus());
        receptionDTO.setSupplier(reception.getSupplier() == null ? null : reception.getSupplier().getId());
        receptionDTO.setReceivedByUser(reception.getReceivedByUser() == null ? null : reception.getReceivedByUser().getId());
        return receptionDTO;
    }

    private Reception mapToEntity(final ReceptionDTO receptionDTO, final Reception reception) {
        reception.setCreatedAt(receptionDTO.getCreatedAt());
        reception.setReceptionDate(receptionDTO.getReceptionDate());
        reception.setStatus(receptionDTO.getStatus());
        final Supplier supplier = receptionDTO.getSupplier() == null ? null : supplierRepository.findById(receptionDTO.getSupplier())
                .orElseThrow(() -> new NotFoundException("supplier not found"));
        reception.setSupplier(supplier);
        final User receivedByUser = receptionDTO.getReceivedByUser() == null ? null : userRepository.findById(receptionDTO.getReceivedByUser())
                .orElseThrow(() -> new NotFoundException("receivedByUser not found"));
        reception.setReceivedByUser(receivedByUser);
        return reception;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Reception reception = receptionRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final ReceptionItem receptionReceptionItem = receptionItemRepository.findFirstByReception(reception);
        if (receptionReceptionItem != null) {
            referencedWarning.setKey("reception.receptionItem.reception.referenced");
            referencedWarning.addParam(receptionReceptionItem.getId());
            return referencedWarning;
        }
        return null;
    }

}
