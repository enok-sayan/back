package io.bootify.my_app.service;

import io.bootify.my_app.domain.Client;
import io.bootify.my_app.domain.Shipment;
import io.bootify.my_app.domain.ShipmentItem;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ShipmentDTO;
import io.bootify.my_app.repos.ClientRepository;
import io.bootify.my_app.repos.ShipmentItemRepository;
import io.bootify.my_app.repos.ShipmentRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import io.bootify.my_app.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ShipmentService {

    private final ShipmentRepository shipmentRepository;
    private final ClientRepository clientRepository;
    private final UserRepository userRepository;
    private final ShipmentItemRepository shipmentItemRepository;

    public ShipmentService(final ShipmentRepository shipmentRepository,
            final ClientRepository clientRepository, final UserRepository userRepository,
            final ShipmentItemRepository shipmentItemRepository) {
        this.shipmentRepository = shipmentRepository;
        this.clientRepository = clientRepository;
        this.userRepository = userRepository;
        this.shipmentItemRepository = shipmentItemRepository;
    }

    public List<ShipmentDTO> findAll() {
        final List<Shipment> shipments = shipmentRepository.findAll(Sort.by("id"));
        return shipments.stream()
                .map(shipment -> mapToDTO(shipment, new ShipmentDTO()))
                .toList();
    }

    public ShipmentDTO get(final Integer id) {
        return shipmentRepository.findById(id)
                .map(shipment -> mapToDTO(shipment, new ShipmentDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final ShipmentDTO shipmentDTO) {
        final Shipment shipment = new Shipment();
        mapToEntity(shipmentDTO, shipment);
        return shipmentRepository.save(shipment).getId();
    }

    public void update(final Integer id, final ShipmentDTO shipmentDTO) {
        final Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(shipmentDTO, shipment);
        shipmentRepository.save(shipment);
    }

    public void delete(final Integer id) {
        shipmentRepository.deleteById(id);
    }

    private ShipmentDTO mapToDTO(final Shipment shipment, final ShipmentDTO shipmentDTO) {
        shipmentDTO.setId(shipment.getId());
        shipmentDTO.setCreatedAt(shipment.getCreatedAt());
        shipmentDTO.setShipmentDate(shipment.getShipmentDate());
        shipmentDTO.setStatus(shipment.getStatus());
        shipmentDTO.setClient(shipment.getClient() == null ? null : shipment.getClient().getId());
        shipmentDTO.setShippedByUser(shipment.getShippedByUser() == null ? null : shipment.getShippedByUser().getId());
        return shipmentDTO;
    }

    private Shipment mapToEntity(final ShipmentDTO shipmentDTO, final Shipment shipment) {
        shipment.setCreatedAt(shipmentDTO.getCreatedAt());
        shipment.setShipmentDate(shipmentDTO.getShipmentDate());
        shipment.setStatus(shipmentDTO.getStatus());
        final Client client = shipmentDTO.getClient() == null ? null : clientRepository.findById(shipmentDTO.getClient())
                .orElseThrow(() -> new NotFoundException("client not found"));
        shipment.setClient(client);
        final User shippedByUser = shipmentDTO.getShippedByUser() == null ? null : userRepository.findById(shipmentDTO.getShippedByUser())
                .orElseThrow(() -> new NotFoundException("shippedByUser not found"));
        shipment.setShippedByUser(shippedByUser);
        return shipment;
    }

    public ReferencedWarning getReferencedWarning(final Integer id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Shipment shipment = shipmentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final ShipmentItem shipmentShipmentItem = shipmentItemRepository.findFirstByShipment(shipment);
        if (shipmentShipmentItem != null) {
            referencedWarning.setKey("shipment.shipmentItem.shipment.referenced");
            referencedWarning.addParam(shipmentShipmentItem.getId());
            return referencedWarning;
        }
        return null;
    }

}
