package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Document;
import io.bootify.my_app.domain.Material;
import org.springframework.data.jpa.repository.JpaRepository;


public interface DocumentRepository extends JpaRepository<Document, Integer> {

    Document findFirstByMaterial(Material material);

}
