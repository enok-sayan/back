package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.model.ReceptionItemDTO;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.ReceptionRepository;
import io.bootify.my_app.service.ReceptionItemService;
import io.bootify.my_app.util.CustomCollectors;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/receptionItems", produces = MediaType.APPLICATION_JSON_VALUE)
public class ReceptionItemResource {

    private final ReceptionItemService receptionItemService;
    private final ReceptionRepository receptionRepository;
    private final MaterialRepository materialRepository;

    public ReceptionItemResource(final ReceptionItemService receptionItemService,
            final ReceptionRepository receptionRepository,
            final MaterialRepository materialRepository) {
        this.receptionItemService = receptionItemService;
        this.receptionRepository = receptionRepository;
        this.materialRepository = materialRepository;
    }

    @GetMapping
    public ResponseEntity<List<ReceptionItemDTO>> getAllReceptionItems() {
        return ResponseEntity.ok(receptionItemService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReceptionItemDTO> getReceptionItem(
            @PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(receptionItemService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createReceptionItem(
            @RequestBody @Valid final ReceptionItemDTO receptionItemDTO) {
        final Integer createdId = receptionItemService.create(receptionItemDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateReceptionItem(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ReceptionItemDTO receptionItemDTO) {
        receptionItemService.update(id, receptionItemDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReceptionItem(@PathVariable(name = "id") final Integer id) {
        receptionItemService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/receptionValues")
    public ResponseEntity<Map<Integer, Integer>> getReceptionValues() {
        return ResponseEntity.ok(receptionRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Reception::getId, Reception::getId)));
    }

    @GetMapping("/materialValues")
    public ResponseEntity<Map<Integer, Integer>> getMaterialValues() {
        return ResponseEntity.ok(materialRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Material::getId, Material::getId)));
    }

}
