package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Client;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.ShipmentDTO;
import io.bootify.my_app.repos.ClientRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.ShipmentService;
import io.bootify.my_app.util.CustomCollectors;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/shipments", produces = MediaType.APPLICATION_JSON_VALUE)
public class ShipmentResource {

    private final ShipmentService shipmentService;
    private final ClientRepository clientRepository;
    private final UserRepository userRepository;

    public ShipmentResource(final ShipmentService shipmentService,
            final ClientRepository clientRepository, final UserRepository userRepository) {
        this.shipmentService = shipmentService;
        this.clientRepository = clientRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<ShipmentDTO>> getAllShipments() {
        return ResponseEntity.ok(shipmentService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ShipmentDTO> getShipment(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(shipmentService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createShipment(
            @RequestBody @Valid final ShipmentDTO shipmentDTO) {
        final Integer createdId = shipmentService.create(shipmentDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateShipment(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final ShipmentDTO shipmentDTO) {
        shipmentService.update(id, shipmentDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteShipment(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = shipmentService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        shipmentService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/clientValues")
    public ResponseEntity<Map<Integer, Integer>> getClientValues() {
        return ResponseEntity.ok(clientRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Client::getId, Client::getId)));
    }

    @GetMapping("/shippedByUserValues")
    public ResponseEntity<Map<Integer, Integer>> getShippedByUserValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

}
