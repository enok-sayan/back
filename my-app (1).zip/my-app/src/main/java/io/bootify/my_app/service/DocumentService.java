package io.bootify.my_app.service;

import io.bootify.my_app.domain.Document;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.model.DocumentDTO;
import io.bootify.my_app.repos.DocumentRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final MaterialRepository materialRepository;

    public DocumentService(final DocumentRepository documentRepository,
            final MaterialRepository materialRepository) {
        this.documentRepository = documentRepository;
        this.materialRepository = materialRepository;
    }

    public List<DocumentDTO> findAll() {
        final List<Document> documents = documentRepository.findAll(Sort.by("id"));
        return documents.stream()
                .map(document -> mapToDTO(document, new DocumentDTO()))
                .toList();
    }

    public DocumentDTO get(final Integer id) {
        return documentRepository.findById(id)
                .map(document -> mapToDTO(document, new DocumentDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final DocumentDTO documentDTO) {
        final Document document = new Document();
        mapToEntity(documentDTO, document);
        return documentRepository.save(document).getId();
    }

    public void update(final Integer id, final DocumentDTO documentDTO) {
        final Document document = documentRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(documentDTO, document);
        documentRepository.save(document);
    }

    public void delete(final Integer id) {
        documentRepository.deleteById(id);
    }

    private DocumentDTO mapToDTO(final Document document, final DocumentDTO documentDTO) {
        documentDTO.setId(document.getId());
        documentDTO.setCreatedAt(document.getCreatedAt());
        documentDTO.setFileUrl(document.getFileUrl());
        documentDTO.setFileType(document.getFileType());
        documentDTO.setDescription(document.getDescription());
        documentDTO.setMaterial(document.getMaterial() == null ? null : document.getMaterial().getId());
        return documentDTO;
    }

    private Document mapToEntity(final DocumentDTO documentDTO, final Document document) {
        document.setCreatedAt(documentDTO.getCreatedAt());
        document.setFileUrl(documentDTO.getFileUrl());
        document.setFileType(documentDTO.getFileType());
        document.setDescription(documentDTO.getDescription());
        final Material material = documentDTO.getMaterial() == null ? null : materialRepository.findById(documentDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        document.setMaterial(material);
        return document;
    }

}
