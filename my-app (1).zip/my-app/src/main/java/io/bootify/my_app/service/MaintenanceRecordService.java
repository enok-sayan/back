package io.bootify.my_app.service;

import io.bootify.my_app.domain.MaintenanceRecord;
import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.MaintenanceRecordDTO;
import io.bootify.my_app.repos.MaintenanceRecordRepository;
import io.bootify.my_app.repos.MaterialRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.util.NotFoundException;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class MaintenanceRecordService {

    private final MaintenanceRecordRepository maintenanceRecordRepository;
    private final MaterialRepository materialRepository;
    private final UserRepository userRepository;

    public MaintenanceRecordService(final MaintenanceRecordRepository maintenanceRecordRepository,
            final MaterialRepository materialRepository, final UserRepository userRepository) {
        this.maintenanceRecordRepository = maintenanceRecordRepository;
        this.materialRepository = materialRepository;
        this.userRepository = userRepository;
    }

    public List<MaintenanceRecordDTO> findAll() {
        final List<MaintenanceRecord> maintenanceRecords = maintenanceRecordRepository.findAll(Sort.by("id"));
        return maintenanceRecords.stream()
                .map(maintenanceRecord -> mapToDTO(maintenanceRecord, new MaintenanceRecordDTO()))
                .toList();
    }

    public MaintenanceRecordDTO get(final Integer id) {
        return maintenanceRecordRepository.findById(id)
                .map(maintenanceRecord -> mapToDTO(maintenanceRecord, new MaintenanceRecordDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Integer create(final MaintenanceRecordDTO maintenanceRecordDTO) {
        final MaintenanceRecord maintenanceRecord = new MaintenanceRecord();
        mapToEntity(maintenanceRecordDTO, maintenanceRecord);
        return maintenanceRecordRepository.save(maintenanceRecord).getId();
    }

    public void update(final Integer id, final MaintenanceRecordDTO maintenanceRecordDTO) {
        final MaintenanceRecord maintenanceRecord = maintenanceRecordRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(maintenanceRecordDTO, maintenanceRecord);
        maintenanceRecordRepository.save(maintenanceRecord);
    }

    public void delete(final Integer id) {
        maintenanceRecordRepository.deleteById(id);
    }

    private MaintenanceRecordDTO mapToDTO(final MaintenanceRecord maintenanceRecord,
            final MaintenanceRecordDTO maintenanceRecordDTO) {
        maintenanceRecordDTO.setId(maintenanceRecord.getId());
        maintenanceRecordDTO.setCreatedAt(maintenanceRecord.getCreatedAt());
        maintenanceRecordDTO.setMaintenanceDate(maintenanceRecord.getMaintenanceDate());
        maintenanceRecordDTO.setMaintenanceType(maintenanceRecord.getMaintenanceType());
        maintenanceRecordDTO.setDescription(maintenanceRecord.getDescription());
        maintenanceRecordDTO.setCost(maintenanceRecord.getCost());
        maintenanceRecordDTO.setCompleted(maintenanceRecord.getCompleted());
        maintenanceRecordDTO.setMaterial(maintenanceRecord.getMaterial() == null ? null : maintenanceRecord.getMaterial().getId());
        maintenanceRecordDTO.setTechnician(maintenanceRecord.getTechnician() == null ? null : maintenanceRecord.getTechnician().getId());
        return maintenanceRecordDTO;
    }

    private MaintenanceRecord mapToEntity(final MaintenanceRecordDTO maintenanceRecordDTO,
            final MaintenanceRecord maintenanceRecord) {
        maintenanceRecord.setCreatedAt(maintenanceRecordDTO.getCreatedAt());
        maintenanceRecord.setMaintenanceDate(maintenanceRecordDTO.getMaintenanceDate());
        maintenanceRecord.setMaintenanceType(maintenanceRecordDTO.getMaintenanceType());
        maintenanceRecord.setDescription(maintenanceRecordDTO.getDescription());
        maintenanceRecord.setCost(maintenanceRecordDTO.getCost());
        maintenanceRecord.setCompleted(maintenanceRecordDTO.getCompleted());
        final Material material = maintenanceRecordDTO.getMaterial() == null ? null : materialRepository.findById(maintenanceRecordDTO.getMaterial())
                .orElseThrow(() -> new NotFoundException("material not found"));
        maintenanceRecord.setMaterial(material);
        final User technician = maintenanceRecordDTO.getTechnician() == null ? null : userRepository.findById(maintenanceRecordDTO.getTechnician())
                .orElseThrow(() -> new NotFoundException("technician not found"));
        maintenanceRecord.setTechnician(technician);
        return maintenanceRecord;
    }

}
