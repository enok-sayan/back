package io.bootify.my_app.rest;

import io.bootify.my_app.domain.Message;
import io.bootify.my_app.domain.User;
import io.bootify.my_app.model.MessageDTO;
import io.bootify.my_app.repos.MessageRepository;
import io.bootify.my_app.repos.UserRepository;
import io.bootify.my_app.service.MessageService;
import io.bootify.my_app.util.CustomCollectors;
import io.bootify.my_app.util.ReferencedException;
import io.bootify.my_app.util.ReferencedWarning;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/messages", produces = MediaType.APPLICATION_JSON_VALUE)
public class MessageResource {

    private final MessageService messageService;
    private final UserRepository userRepository;
    private final MessageRepository messageRepository;

    public MessageResource(final MessageService messageService, final UserRepository userRepository,
            final MessageRepository messageRepository) {
        this.messageService = messageService;
        this.userRepository = userRepository;
        this.messageRepository = messageRepository;
    }

    @GetMapping
    public ResponseEntity<List<MessageDTO>> getAllMessages() {
        return ResponseEntity.ok(messageService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MessageDTO> getMessage(@PathVariable(name = "id") final Integer id) {
        return ResponseEntity.ok(messageService.get(id));
    }

    @PostMapping
    public ResponseEntity<Integer> createMessage(@RequestBody @Valid final MessageDTO messageDTO) {
        final Integer createdId = messageService.create(messageDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Integer> updateMessage(@PathVariable(name = "id") final Integer id,
            @RequestBody @Valid final MessageDTO messageDTO) {
        messageService.update(id, messageDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMessage(@PathVariable(name = "id") final Integer id) {
        final ReferencedWarning referencedWarning = messageService.getReferencedWarning(id);
        if (referencedWarning != null) {
            throw new ReferencedException(referencedWarning);
        }
        messageService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/senderValues")
    public ResponseEntity<Map<Integer, Integer>> getSenderValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

    @GetMapping("/receiverValues")
    public ResponseEntity<Map<Integer, Integer>> getReceiverValues() {
        return ResponseEntity.ok(userRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(User::getId, User::getId)));
    }

    @GetMapping("/parentMessageValues")
    public ResponseEntity<Map<Integer, Integer>> getParentMessageValues() {
        return ResponseEntity.ok(messageRepository.findAll(Sort.by("id"))
                .stream()
                .collect(CustomCollectors.toSortedMap(Message::getId, Message::getId)));
    }

}
