package io.bootify.my_app.repos;

import io.bootify.my_app.domain.Material;
import io.bootify.my_app.domain.Reception;
import io.bootify.my_app.domain.ReceptionItem;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ReceptionItemRepository extends JpaRepository<ReceptionItem, Integer> {

    ReceptionItem findFirstByReception(Reception reception);

    ReceptionItem findFirstByMaterial(Material material);

}
