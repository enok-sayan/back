export const environment = {
  production: false,
  apiPath: 'http://localhost:8080'
};
