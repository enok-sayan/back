export class StockMovementDTO {

  constructor(data:Partial<StockMovementDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  type?: string|null;
  quantityChange?: number|null;
  newQuantity?: number|null;
  timestamp?: string|null;
  material?: number|null;
  location?: number|null;
  user?: number|null;

}
