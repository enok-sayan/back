import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { StockMovementDTO } from 'app/stock-movement/stock-movement.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class StockMovementService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/stockMovements';

  getAllStockMovements() {
    return this.http.get<StockMovementDTO[]>(this.resourcePath);
  }

  getStockMovement(id: number) {
    return this.http.get<StockMovementDTO>(this.resourcePath + '/' + id);
  }

  createStockMovement(stockMovementDTO: StockMovementDTO) {
    return this.http.post<number>(this.resourcePath, stockMovementDTO);
  }

  updateStockMovement(id: number, stockMovementDTO: StockMovementDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, stockMovementDTO);
  }

  deleteStockMovement(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

  getLocationValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/locationValues')
        .pipe(map(transformRecordToMap));
  }

  getUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/userValues')
        .pipe(map(transformRecordToMap));
  }

}
