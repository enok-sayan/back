import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { StockMovementService } from 'app/stock-movement/stock-movement.service';
import { StockMovementDTO } from 'app/stock-movement/stock-movement.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-stock-movement-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './stock-movement-edit.component.html'
})
export class StockMovementEditComponent implements OnInit {

  stockMovementService = inject(StockMovementService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  materialValues?: Map<number,string>;
  locationValues?: Map<number,string>;
  userValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    type: new FormControl(null),
    quantityChange: new FormControl(null),
    newQuantity: new FormControl(null),
    timestamp: new FormControl(null, [validOffsetDateTime]),
    material: new FormControl(null),
    location: new FormControl(null),
    user: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@stockMovement.update.success:Stock Movement was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.stockMovementService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.stockMovementService.getLocationValues()
        .subscribe({
          next: (data) => this.locationValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.stockMovementService.getUserValues()
        .subscribe({
          next: (data) => this.userValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.stockMovementService.getStockMovement(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new StockMovementDTO(this.editForm.value);
    this.stockMovementService.updateStockMovement(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/stockMovements'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
