import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { LocationService } from 'app/location/location.service';
import { LocationDTO } from 'app/location/location.model';


@Component({
  selector: 'app-location-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './location-list.component.html'})
export class LocationListComponent implements OnInit, OnDestroy {

  locationService = inject(LocationService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  locations?: LocationDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@location.delete.success:Location was removed successfully.`,
      'location.stock.location.referenced': $localize`:@@location.stock.location.referenced:This entity is still referenced by Stock ${details?.id} via field Location.`,
      'location.stockMovement.location.referenced': $localize`:@@location.stockMovement.location.referenced:This entity is still referenced by Stock Movement ${details?.id} via field Location.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.locationService.getAllLocations()
        .subscribe({
          next: (data) => this.locations = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.locationService.deleteLocation(id)
        .subscribe({
          next: () => this.router.navigate(['/locations'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => {
            if (error.error?.code === 'REFERENCED') {
              const messageParts = error.error.message.split(',');
              this.router.navigate(['/locations'], {
                state: {
                  msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                }
              });
              return;
            }
            this.errorHandler.handleServerError(error.error)
          }
        });
  }

}
