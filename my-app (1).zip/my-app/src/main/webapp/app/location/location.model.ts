export class LocationDTO {

  constructor(data:Partial<LocationDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  description?: string|null;

}
