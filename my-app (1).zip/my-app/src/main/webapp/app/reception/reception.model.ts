export class ReceptionDTO {

  constructor(data:Partial<ReceptionDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  receptionDate?: string|null;
  status?: string|null;
  supplier?: number|null;
  receivedByUser?: number|null;

}
