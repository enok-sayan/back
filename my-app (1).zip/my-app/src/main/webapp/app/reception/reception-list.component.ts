import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ReceptionService } from 'app/reception/reception.service';
import { ReceptionDTO } from 'app/reception/reception.model';


@Component({
  selector: 'app-reception-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './reception-list.component.html'})
export class ReceptionListComponent implements OnInit, OnDestroy {

  receptionService = inject(ReceptionService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  receptions?: ReceptionDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@reception.delete.success:Reception was removed successfully.`,
      'reception.receptionItem.reception.referenced': $localize`:@@reception.receptionItem.reception.referenced:This entity is still referenced by Reception Item ${details?.id} via field Reception.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.receptionService.getAllReceptions()
        .subscribe({
          next: (data) => this.receptions = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.receptionService.deleteReception(id)
        .subscribe({
          next: () => this.router.navigate(['/receptions'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => {
            if (error.error?.code === 'REFERENCED') {
              const messageParts = error.error.message.split(',');
              this.router.navigate(['/receptions'], {
                state: {
                  msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                }
              });
              return;
            }
            this.errorHandler.handleServerError(error.error)
          }
        });
  }

}
