import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ReceptionDTO } from 'app/reception/reception.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class ReceptionService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/receptions';

  getAllReceptions() {
    return this.http.get<ReceptionDTO[]>(this.resourcePath);
  }

  getReception(id: number) {
    return this.http.get<ReceptionDTO>(this.resourcePath + '/' + id);
  }

  createReception(receptionDTO: ReceptionDTO) {
    return this.http.post<number>(this.resourcePath, receptionDTO);
  }

  updateReception(id: number, receptionDTO: ReceptionDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, receptionDTO);
  }

  deleteReception(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getSupplierValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/supplierValues')
        .pipe(map(transformRecordToMap));
  }

  getReceivedByUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/receivedByUserValues')
        .pipe(map(transformRecordToMap));
  }

}
