import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ReceptionService } from 'app/reception/reception.service';
import { ReceptionDTO } from 'app/reception/reception.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-reception-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './reception-edit.component.html'
})
export class ReceptionEditComponent implements OnInit {

  receptionService = inject(ReceptionService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  supplierValues?: Map<number,string>;
  receivedByUserValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    receptionDate: new FormControl(null, [Validators.required]),
    status: new FormControl(null),
    supplier: new FormControl(null),
    receivedByUser: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@reception.update.success:Reception was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.receptionService.getSupplierValues()
        .subscribe({
          next: (data) => this.supplierValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.receptionService.getReceivedByUserValues()
        .subscribe({
          next: (data) => this.receivedByUserValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.receptionService.getReception(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new ReceptionDTO(this.editForm.value);
    this.receptionService.updateReception(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/receptions'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
