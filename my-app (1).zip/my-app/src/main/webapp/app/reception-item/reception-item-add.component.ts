import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ReceptionItemService } from 'app/reception-item/reception-item.service';
import { ReceptionItemDTO } from 'app/reception-item/reception-item.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-reception-item-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './reception-item-add.component.html'
})
export class ReceptionItemAddComponent implements OnInit {

  receptionItemService = inject(ReceptionItemService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  receptionValues?: Map<number,string>;
  materialValues?: Map<number,string>;

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    quantityReceived: new FormControl(null, [Validators.required]),
    batchNumber: new FormControl(null),
    expiryDate: new FormControl(null),
    reception: new FormControl(null),
    material: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@receptionItem.create.success:Reception Item was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.receptionItemService.getReceptionValues()
        .subscribe({
          next: (data) => this.receptionValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.receptionItemService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new ReceptionItemDTO(this.addForm.value);
    this.receptionItemService.createReceptionItem(data)
        .subscribe({
          next: () => this.router.navigate(['/receptionItems'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
