export class ReceptionItemDTO {

  constructor(data:Partial<ReceptionItemDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  quantityReceived?: number|null;
  batchNumber?: string|null;
  expiryDate?: string|null;
  reception?: number|null;
  material?: number|null;

}
