import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ReceptionItemDTO } from 'app/reception-item/reception-item.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class ReceptionItemService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/receptionItems';

  getAllReceptionItems() {
    return this.http.get<ReceptionItemDTO[]>(this.resourcePath);
  }

  getReceptionItem(id: number) {
    return this.http.get<ReceptionItemDTO>(this.resourcePath + '/' + id);
  }

  createReceptionItem(receptionItemDTO: ReceptionItemDTO) {
    return this.http.post<number>(this.resourcePath, receptionItemDTO);
  }

  updateReceptionItem(id: number, receptionItemDTO: ReceptionItemDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, receptionItemDTO);
  }

  deleteReceptionItem(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getReceptionValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/receptionValues')
        .pipe(map(transformRecordToMap));
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

}
