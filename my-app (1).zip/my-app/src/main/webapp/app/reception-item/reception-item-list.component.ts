import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ReceptionItemService } from 'app/reception-item/reception-item.service';
import { ReceptionItemDTO } from 'app/reception-item/reception-item.model';


@Component({
  selector: 'app-reception-item-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './reception-item-list.component.html'})
export class ReceptionItemListComponent implements OnInit, OnDestroy {

  receptionItemService = inject(ReceptionItemService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  receptionItems?: ReceptionItemDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@receptionItem.delete.success:Reception Item was removed successfully.`    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.receptionItemService.getAllReceptionItems()
        .subscribe({
          next: (data) => this.receptionItems = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.receptionItemService.deleteReceptionItem(id)
        .subscribe({
          next: () => this.router.navigate(['/receptionItems'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

}
