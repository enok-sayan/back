import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ManufacturerDTO } from 'app/manufacturer/manufacturer.model';


@Injectable({
  providedIn: 'root',
})
export class ManufacturerService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/manufacturers';

  getAllManufacturers() {
    return this.http.get<ManufacturerDTO[]>(this.resourcePath);
  }

  getManufacturer(id: number) {
    return this.http.get<ManufacturerDTO>(this.resourcePath + '/' + id);
  }

  createManufacturer(manufacturerDTO: ManufacturerDTO) {
    return this.http.post<number>(this.resourcePath, manufacturerDTO);
  }

  updateManufacturer(id: number, manufacturerDTO: ManufacturerDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, manufacturerDTO);
  }

  deleteManufacturer(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
