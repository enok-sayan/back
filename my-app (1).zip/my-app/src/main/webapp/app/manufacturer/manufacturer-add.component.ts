import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ManufacturerService } from 'app/manufacturer/manufacturer.service';
import { ManufacturerDTO } from 'app/manufacturer/manufacturer.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-manufacturer-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './manufacturer-add.component.html'
})
export class ManufacturerAddComponent {

  manufacturerService = inject(ManufacturerService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    name: new FormControl(null, [Validators.required]),
    country: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@manufacturer.create.success:Manufacturer was created successfully.`
    };
    return messages[key];
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new ManufacturerDTO(this.addForm.value);
    this.manufacturerService.createManufacturer(data)
        .subscribe({
          next: () => this.router.navigate(['/manufacturers'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
