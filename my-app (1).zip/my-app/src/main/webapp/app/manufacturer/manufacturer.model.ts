export class ManufacturerDTO {

  constructor(data:Partial<ManufacturerDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  country?: string|null;

}
