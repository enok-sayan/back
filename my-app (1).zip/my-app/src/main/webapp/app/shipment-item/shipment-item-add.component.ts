import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ShipmentItemService } from 'app/shipment-item/shipment-item.service';
import { ShipmentItemDTO } from 'app/shipment-item/shipment-item.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-shipment-item-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './shipment-item-add.component.html'
})
export class ShipmentItemAddComponent implements OnInit {

  shipmentItemService = inject(ShipmentItemService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  shipmentValues?: Map<number,string>;
  materialValues?: Map<number,string>;

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    quantityShipped: new FormControl(null, [Validators.required]),
    shipment: new FormControl(null),
    material: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@shipmentItem.create.success:Shipment Item was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.shipmentItemService.getShipmentValues()
        .subscribe({
          next: (data) => this.shipmentValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.shipmentItemService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new ShipmentItemDTO(this.addForm.value);
    this.shipmentItemService.createShipmentItem(data)
        .subscribe({
          next: () => this.router.navigate(['/shipmentItems'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
