export class ShipmentItemDTO {

  constructor(data:Partial<ShipmentItemDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  quantityShipped?: number|null;
  shipment?: number|null;
  material?: number|null;

}
