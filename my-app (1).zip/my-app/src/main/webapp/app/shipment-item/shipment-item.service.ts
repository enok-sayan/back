import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ShipmentItemDTO } from 'app/shipment-item/shipment-item.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class ShipmentItemService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/shipmentItems';

  getAllShipmentItems() {
    return this.http.get<ShipmentItemDTO[]>(this.resourcePath);
  }

  getShipmentItem(id: number) {
    return this.http.get<ShipmentItemDTO>(this.resourcePath + '/' + id);
  }

  createShipmentItem(shipmentItemDTO: ShipmentItemDTO) {
    return this.http.post<number>(this.resourcePath, shipmentItemDTO);
  }

  updateShipmentItem(id: number, shipmentItemDTO: ShipmentItemDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, shipmentItemDTO);
  }

  deleteShipmentItem(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getShipmentValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/shipmentValues')
        .pipe(map(transformRecordToMap));
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

}
