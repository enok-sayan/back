import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ShipmentItemService } from 'app/shipment-item/shipment-item.service';
import { ShipmentItemDTO } from 'app/shipment-item/shipment-item.model';


@Component({
  selector: 'app-shipment-item-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './shipment-item-list.component.html'})
export class ShipmentItemListComponent implements OnInit, OnDestroy {

  shipmentItemService = inject(ShipmentItemService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  shipmentItems?: ShipmentItemDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@shipmentItem.delete.success:Shipment Item was removed successfully.`    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.shipmentItemService.getAllShipmentItems()
        .subscribe({
          next: (data) => this.shipmentItems = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.shipmentItemService.deleteShipmentItem(id)
        .subscribe({
          next: () => this.router.navigate(['/shipmentItems'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

}
