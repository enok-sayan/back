import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { MaterialService } from 'app/material/material.service';
import { MaterialDTO } from 'app/material/material.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validNumeric, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-material-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './material-edit.component.html'
})
export class MaterialEditComponent implements OnInit {

  materialService = inject(MaterialService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  categoryValues?: Map<number,string>;
  materialStatusValues?: Map<number,string>;
  supplierValues?: Map<number,string>;
  manufacturerValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    name: new FormControl(null, [Validators.required]),
    description: new FormControl(null),
    serialNumber: new FormControl(null),
    quantity: new FormControl(null),
    available: new FormControl(false),
    purchaseDate: new FormControl(null),
    purchasePrice: new FormControl(null, [validNumeric(10, 2)]),
    imageUrl: new FormControl(null),
    minStockLevel: new FormControl(null),
    category: new FormControl(null),
    materialStatus: new FormControl(null),
    supplier: new FormControl(null),
    manufacturer: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@material.update.success:Material was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.materialService.getCategoryValues()
        .subscribe({
          next: (data) => this.categoryValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getMaterialStatusValues()
        .subscribe({
          next: (data) => this.materialStatusValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getSupplierValues()
        .subscribe({
          next: (data) => this.supplierValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getManufacturerValues()
        .subscribe({
          next: (data) => this.manufacturerValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getMaterial(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new MaterialDTO(this.editForm.value);
    this.materialService.updateMaterial(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/materials'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
