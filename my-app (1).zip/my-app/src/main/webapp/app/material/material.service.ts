import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { MaterialDTO } from 'app/material/material.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class MaterialService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/materials';

  getAllMaterials() {
    return this.http.get<MaterialDTO[]>(this.resourcePath);
  }

  getMaterial(id: number) {
    return this.http.get<MaterialDTO>(this.resourcePath + '/' + id);
  }

  createMaterial(materialDTO: MaterialDTO) {
    return this.http.post<number>(this.resourcePath, materialDTO);
  }

  updateMaterial(id: number, materialDTO: MaterialDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, materialDTO);
  }

  deleteMaterial(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getCategoryValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/categoryValues')
        .pipe(map(transformRecordToMap));
  }

  getMaterialStatusValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialStatusValues')
        .pipe(map(transformRecordToMap));
  }

  getSupplierValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/supplierValues')
        .pipe(map(transformRecordToMap));
  }

  getManufacturerValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/manufacturerValues')
        .pipe(map(transformRecordToMap));
  }

}
