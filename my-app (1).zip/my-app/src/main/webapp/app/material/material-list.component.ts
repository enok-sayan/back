import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { MaterialService } from 'app/material/material.service';
import { MaterialDTO } from 'app/material/material.model';


@Component({
  selector: 'app-material-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './material-list.component.html'})
export class MaterialListComponent implements OnInit, OnDestroy {

  materialService = inject(MaterialService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  materials?: MaterialDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@material.delete.success:Material was removed successfully.`,
      'material.stock.material.referenced': $localize`:@@material.stock.material.referenced:This entity is still referenced by Stock ${details?.id} via field Material.`,
      'material.stockMovement.material.referenced': $localize`:@@material.stockMovement.material.referenced:This entity is still referenced by Stock Movement ${details?.id} via field Material.`,
      'material.shipmentItem.material.referenced': $localize`:@@material.shipmentItem.material.referenced:This entity is still referenced by Shipment Item ${details?.id} via field Material.`,
      'material.receptionItem.material.referenced': $localize`:@@material.receptionItem.material.referenced:This entity is still referenced by Reception Item ${details?.id} via field Material.`,
      'material.maintenanceRecord.material.referenced': $localize`:@@material.maintenanceRecord.material.referenced:This entity is still referenced by Maintenance Record ${details?.id} via field Material.`,
      'material.document.material.referenced': $localize`:@@material.document.material.referenced:This entity is still referenced by Document ${details?.id} via field Material.`,
      'material.borrowRequest.material.referenced': $localize`:@@material.borrowRequest.material.referenced:This entity is still referenced by Borrow Request ${details?.id} via field Material.`,
      'material.alert.material.referenced': $localize`:@@material.alert.material.referenced:This entity is still referenced by Alert ${details?.id} via field Material.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.materialService.getAllMaterials()
        .subscribe({
          next: (data) => this.materials = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.materialService.deleteMaterial(id)
        .subscribe({
          next: () => this.router.navigate(['/materials'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => {
            if (error.error?.code === 'REFERENCED') {
              const messageParts = error.error.message.split(',');
              this.router.navigate(['/materials'], {
                state: {
                  msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                }
              });
              return;
            }
            this.errorHandler.handleServerError(error.error)
          }
        });
  }

}
