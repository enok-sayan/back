export class MaterialDTO {

  constructor(data:Partial<MaterialDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  description?: string|null;
  serialNumber?: string|null;
  quantity?: number|null;
  available?: boolean|null;
  purchaseDate?: string|null;
  purchasePrice?: string|null;
  imageUrl?: string|null;
  minStockLevel?: number|null;
  category?: number|null;
  materialStatus?: number|null;
  supplier?: number|null;
  manufacturer?: number|null;

}
