import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { MaterialService } from 'app/material/material.service';
import { MaterialDTO } from 'app/material/material.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validNumeric, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-material-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './material-add.component.html'
})
export class MaterialAddComponent implements OnInit {

  materialService = inject(MaterialService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  categoryValues?: Map<number,string>;
  materialStatusValues?: Map<number,string>;
  supplierValues?: Map<number,string>;
  manufacturerValues?: Map<number,string>;

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    name: new FormControl(null, [Validators.required]),
    description: new FormControl(null),
    serialNumber: new FormControl(null),
    quantity: new FormControl(null),
    available: new FormControl(false),
    purchaseDate: new FormControl(null),
    purchasePrice: new FormControl(null, [validNumeric(10, 2)]),
    imageUrl: new FormControl(null),
    minStockLevel: new FormControl(null),
    category: new FormControl(null),
    materialStatus: new FormControl(null),
    supplier: new FormControl(null),
    manufacturer: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@material.create.success:Material was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.materialService.getCategoryValues()
        .subscribe({
          next: (data) => this.categoryValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getMaterialStatusValues()
        .subscribe({
          next: (data) => this.materialStatusValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getSupplierValues()
        .subscribe({
          next: (data) => this.supplierValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.materialService.getManufacturerValues()
        .subscribe({
          next: (data) => this.manufacturerValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new MaterialDTO(this.addForm.value);
    this.materialService.createMaterial(data)
        .subscribe({
          next: () => this.router.navigate(['/materials'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
