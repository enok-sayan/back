export class StockDTO {

  constructor(data:Partial<StockDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  quantity?: number|null;
  material?: number|null;
  location?: number|null;

}
