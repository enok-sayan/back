import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { StockDTO } from 'app/stock/stock.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class StockService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/stocks';

  getAllStocks() {
    return this.http.get<StockDTO[]>(this.resourcePath);
  }

  getStock(id: number) {
    return this.http.get<StockDTO>(this.resourcePath + '/' + id);
  }

  createStock(stockDTO: StockDTO) {
    return this.http.post<number>(this.resourcePath, stockDTO);
  }

  updateStock(id: number, stockDTO: StockDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, stockDTO);
  }

  deleteStock(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

  getLocationValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/locationValues')
        .pipe(map(transformRecordToMap));
  }

}
