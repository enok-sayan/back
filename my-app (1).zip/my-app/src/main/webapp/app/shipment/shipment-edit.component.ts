import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { ShipmentService } from 'app/shipment/shipment.service';
import { ShipmentDTO } from 'app/shipment/shipment.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-shipment-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './shipment-edit.component.html'
})
export class ShipmentEditComponent implements OnInit {

  shipmentService = inject(ShipmentService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  clientValues?: Map<number,string>;
  shippedByUserValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    shipmentDate: new FormControl(null, [Validators.required]),
    status: new FormControl(null),
    client: new FormControl(null),
    shippedByUser: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@shipment.update.success:Shipment was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.shipmentService.getClientValues()
        .subscribe({
          next: (data) => this.clientValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.shipmentService.getShippedByUserValues()
        .subscribe({
          next: (data) => this.shippedByUserValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.shipmentService.getShipment(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new ShipmentDTO(this.editForm.value);
    this.shipmentService.updateShipment(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/shipments'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
