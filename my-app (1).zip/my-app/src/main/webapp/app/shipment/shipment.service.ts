import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { ShipmentDTO } from 'app/shipment/shipment.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class ShipmentService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/shipments';

  getAllShipments() {
    return this.http.get<ShipmentDTO[]>(this.resourcePath);
  }

  getShipment(id: number) {
    return this.http.get<ShipmentDTO>(this.resourcePath + '/' + id);
  }

  createShipment(shipmentDTO: ShipmentDTO) {
    return this.http.post<number>(this.resourcePath, shipmentDTO);
  }

  updateShipment(id: number, shipmentDTO: ShipmentDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, shipmentDTO);
  }

  deleteShipment(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getClientValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/clientValues')
        .pipe(map(transformRecordToMap));
  }

  getShippedByUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/shippedByUserValues')
        .pipe(map(transformRecordToMap));
  }

}
