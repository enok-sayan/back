export class ShipmentDTO {

  constructor(data:Partial<ShipmentDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  shipmentDate?: string|null;
  status?: string|null;
  client?: number|null;
  shippedByUser?: number|null;

}
