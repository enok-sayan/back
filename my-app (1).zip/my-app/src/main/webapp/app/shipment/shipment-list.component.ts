import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { ShipmentService } from 'app/shipment/shipment.service';
import { ShipmentDTO } from 'app/shipment/shipment.model';


@Component({
  selector: 'app-shipment-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './shipment-list.component.html'})
export class ShipmentListComponent implements OnInit, OnDestroy {

  shipmentService = inject(ShipmentService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  shipments?: ShipmentDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@shipment.delete.success:Shipment was removed successfully.`,
      'shipment.shipmentItem.shipment.referenced': $localize`:@@shipment.shipmentItem.shipment.referenced:This entity is still referenced by Shipment Item ${details?.id} via field Shipment.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.shipmentService.getAllShipments()
        .subscribe({
          next: (data) => this.shipments = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.shipmentService.deleteShipment(id)
        .subscribe({
          next: () => this.router.navigate(['/shipments'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => {
            if (error.error?.code === 'REFERENCED') {
              const messageParts = error.error.message.split(',');
              this.router.navigate(['/shipments'], {
                state: {
                  msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                }
              });
              return;
            }
            this.errorHandler.handleServerError(error.error)
          }
        });
  }

}
