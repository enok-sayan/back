export class CategoryDTO {

  constructor(data:Partial<CategoryDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  description?: string|null;

}
