import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { SupplierDTO } from 'app/supplier/supplier.model';


@Injectable({
  providedIn: 'root',
})
export class SupplierService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/suppliers';

  getAllSuppliers() {
    return this.http.get<SupplierDTO[]>(this.resourcePath);
  }

  getSupplier(id: number) {
    return this.http.get<SupplierDTO>(this.resourcePath + '/' + id);
  }

  createSupplier(supplierDTO: SupplierDTO) {
    return this.http.post<number>(this.resourcePath, supplierDTO);
  }

  updateSupplier(id: number, supplierDTO: SupplierDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, supplierDTO);
  }

  deleteSupplier(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
