export class SupplierDTO {

  constructor(data:Partial<SupplierDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  contactPerson?: string|null;
  phone?: string|null;
  email?: string|null;
  address?: string|null;

}
