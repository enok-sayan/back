import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { UserRoleDTO } from 'app/user-role/user-role.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class UserRoleService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/userRoles';

  getAllUserRoles() {
    return this.http.get<UserRoleDTO[]>(this.resourcePath);
  }

  getUserRole(id: number) {
    return this.http.get<UserRoleDTO>(this.resourcePath + '/' + id);
  }

  createUserRole(userRoleDTO: UserRoleDTO) {
    return this.http.post<number>(this.resourcePath, userRoleDTO);
  }

  updateUserRole(id: number, userRoleDTO: UserRoleDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, userRoleDTO);
  }

  deleteUserRole(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/userValues')
        .pipe(map(transformRecordToMap));
  }

  getRoleValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/roleValues')
        .pipe(map(transformRecordToMap));
  }

}
