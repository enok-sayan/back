export class UserRoleDTO {

  constructor(data:Partial<UserRoleDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  user?: number|null;
  role?: number|null;

}
