import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { UserTypeDTO } from 'app/user-type/user-type.model';


@Injectable({
  providedIn: 'root',
})
export class UserTypeService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/userTypes';

  getAllUserTypes() {
    return this.http.get<UserTypeDTO[]>(this.resourcePath);
  }

  getUserType(id: number) {
    return this.http.get<UserTypeDTO>(this.resourcePath + '/' + id);
  }

  createUserType(userTypeDTO: UserTypeDTO) {
    return this.http.post<number>(this.resourcePath, userTypeDTO);
  }

  updateUserType(id: number, userTypeDTO: UserTypeDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, userTypeDTO);
  }

  deleteUserType(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
