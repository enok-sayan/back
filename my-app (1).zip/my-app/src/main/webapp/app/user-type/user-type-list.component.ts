import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { Subscription } from 'rxjs';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { UserTypeService } from 'app/user-type/user-type.service';
import { UserTypeDTO } from 'app/user-type/user-type.model';


@Component({
  selector: 'app-user-type-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './user-type-list.component.html'})
export class UserTypeListComponent implements OnInit, OnDestroy {

  userTypeService = inject(UserTypeService);
  errorHandler = inject(ErrorHandler);
  router = inject(Router);
  userTypes?: UserTypeDTO[];
  navigationSubscription?: Subscription;

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      confirm: $localize`:@@delete.confirm:Do you really want to delete this element? This cannot be undone.`,
      deleted: $localize`:@@userType.delete.success:User Type was removed successfully.`,
      'userType.user.userType.referenced': $localize`:@@userType.user.userType.referenced:This entity is still referenced by User ${details?.id} via field User Type.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.loadData();
    this.navigationSubscription = this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.loadData();
      }
    });
  }

  ngOnDestroy() {
    this.navigationSubscription!.unsubscribe();
  }
  
  loadData() {
    this.userTypeService.getAllUserTypes()
        .subscribe({
          next: (data) => this.userTypes = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  confirmDelete(id: number) {
    if (!confirm(this.getMessage('confirm'))) {
      return;
    }
    this.userTypeService.deleteUserType(id)
        .subscribe({
          next: () => this.router.navigate(['/userTypes'], {
            state: {
              msgInfo: this.getMessage('deleted')
            }
          }),
          error: (error) => {
            if (error.error?.code === 'REFERENCED') {
              const messageParts = error.error.message.split(',');
              this.router.navigate(['/userTypes'], {
                state: {
                  msgError: this.getMessage(messageParts[0], { id: messageParts[1] })
                }
              });
              return;
            }
            this.errorHandler.handleServerError(error.error)
          }
        });
  }

}
