export class UserTypeDTO {

  constructor(data:Partial<UserTypeDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  description?: string|null;
  permissionLevel?: string|null;

}
