export class ActivityLogDTO {

  constructor(data:Partial<ActivityLogDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  action?: string|null;
  details?: string|null;
  timestamp?: string|null;
  user?: number|null;

}
