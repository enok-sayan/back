import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserTypeListComponent } from './user-type/user-type-list.component';
import { UserTypeAddComponent } from './user-type/user-type-add.component';
import { UserTypeEditComponent } from './user-type/user-type-edit.component';
import { RoleListComponent } from './role/role-list.component';
import { RoleAddComponent } from './role/role-add.component';
import { RoleEditComponent } from './role/role-edit.component';
import { UserListComponent } from './user/user-list.component';
import { UserAddComponent } from './user/user-add.component';
import { UserEditComponent } from './user/user-edit.component';
import { UserRoleListComponent } from './user-role/user-role-list.component';
import { UserRoleAddComponent } from './user-role/user-role-add.component';
import { UserRoleEditComponent } from './user-role/user-role-edit.component';
import { ManufacturerListComponent } from './manufacturer/manufacturer-list.component';
import { ManufacturerAddComponent } from './manufacturer/manufacturer-add.component';
import { ManufacturerEditComponent } from './manufacturer/manufacturer-edit.component';
import { SupplierListComponent } from './supplier/supplier-list.component';
import { SupplierAddComponent } from './supplier/supplier-add.component';
import { SupplierEditComponent } from './supplier/supplier-edit.component';
import { CategoryListComponent } from './category/category-list.component';
import { CategoryAddComponent } from './category/category-add.component';
import { CategoryEditComponent } from './category/category-edit.component';
import { MaterialStatusListComponent } from './material-status/material-status-list.component';
import { MaterialStatusAddComponent } from './material-status/material-status-add.component';
import { MaterialStatusEditComponent } from './material-status/material-status-edit.component';
import { MaterialListComponent } from './material/material-list.component';
import { MaterialAddComponent } from './material/material-add.component';
import { MaterialEditComponent } from './material/material-edit.component';
import { LocationListComponent } from './location/location-list.component';
import { LocationAddComponent } from './location/location-add.component';
import { LocationEditComponent } from './location/location-edit.component';
import { StockListComponent } from './stock/stock-list.component';
import { StockAddComponent } from './stock/stock-add.component';
import { StockEditComponent } from './stock/stock-edit.component';
import { StockMovementListComponent } from './stock-movement/stock-movement-list.component';
import { StockMovementAddComponent } from './stock-movement/stock-movement-add.component';
import { StockMovementEditComponent } from './stock-movement/stock-movement-edit.component';
import { ClientListComponent } from './client/client-list.component';
import { ClientAddComponent } from './client/client-add.component';
import { ClientEditComponent } from './client/client-edit.component';
import { ShipmentListComponent } from './shipment/shipment-list.component';
import { ShipmentAddComponent } from './shipment/shipment-add.component';
import { ShipmentEditComponent } from './shipment/shipment-edit.component';
import { ShipmentItemListComponent } from './shipment-item/shipment-item-list.component';
import { ShipmentItemAddComponent } from './shipment-item/shipment-item-add.component';
import { ShipmentItemEditComponent } from './shipment-item/shipment-item-edit.component';
import { ReceptionListComponent } from './reception/reception-list.component';
import { ReceptionAddComponent } from './reception/reception-add.component';
import { ReceptionEditComponent } from './reception/reception-edit.component';
import { ReceptionItemListComponent } from './reception-item/reception-item-list.component';
import { ReceptionItemAddComponent } from './reception-item/reception-item-add.component';
import { ReceptionItemEditComponent } from './reception-item/reception-item-edit.component';
import { MaintenanceRecordListComponent } from './maintenance-record/maintenance-record-list.component';
import { MaintenanceRecordAddComponent } from './maintenance-record/maintenance-record-add.component';
import { MaintenanceRecordEditComponent } from './maintenance-record/maintenance-record-edit.component';
import { DocumentListComponent } from './document/document-list.component';
import { DocumentAddComponent } from './document/document-add.component';
import { DocumentEditComponent } from './document/document-edit.component';
import { BorrowRequestListComponent } from './borrow-request/borrow-request-list.component';
import { BorrowRequestAddComponent } from './borrow-request/borrow-request-add.component';
import { BorrowRequestEditComponent } from './borrow-request/borrow-request-edit.component';
import { AlertListComponent } from './alert/alert-list.component';
import { AlertAddComponent } from './alert/alert-add.component';
import { AlertEditComponent } from './alert/alert-edit.component';
import { ActivityLogListComponent } from './activity-log/activity-log-list.component';
import { ActivityLogAddComponent } from './activity-log/activity-log-add.component';
import { ActivityLogEditComponent } from './activity-log/activity-log-edit.component';
import { MessageListComponent } from './message/message-list.component';
import { MessageAddComponent } from './message/message-add.component';
import { MessageEditComponent } from './message/message-edit.component';
import { ErrorComponent } from './error/error.component';


export const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    title: $localize`:@@home.index.headline:Welcome to your new app!`
  },
  {
    path: 'userTypes',
    component: UserTypeListComponent,
    title: $localize`:@@userType.list.headline:User Types`
  },
  {
    path: 'userTypes/add',
    component: UserTypeAddComponent,
    title: $localize`:@@userType.add.headline:Add User Type`
  },
  {
    path: 'userTypes/edit/:id',
    component: UserTypeEditComponent,
    title: $localize`:@@userType.edit.headline:Edit User Type`
  },
  {
    path: 'roles',
    component: RoleListComponent,
    title: $localize`:@@role.list.headline:Roles`
  },
  {
    path: 'roles/add',
    component: RoleAddComponent,
    title: $localize`:@@role.add.headline:Add Role`
  },
  {
    path: 'roles/edit/:id',
    component: RoleEditComponent,
    title: $localize`:@@role.edit.headline:Edit Role`
  },
  {
    path: 'users',
    component: UserListComponent,
    title: $localize`:@@user.list.headline:Users`
  },
  {
    path: 'users/add',
    component: UserAddComponent,
    title: $localize`:@@user.add.headline:Add User`
  },
  {
    path: 'users/edit/:id',
    component: UserEditComponent,
    title: $localize`:@@user.edit.headline:Edit User`
  },
  {
    path: 'userRoles',
    component: UserRoleListComponent,
    title: $localize`:@@userRole.list.headline:User Roles`
  },
  {
    path: 'userRoles/add',
    component: UserRoleAddComponent,
    title: $localize`:@@userRole.add.headline:Add User Role`
  },
  {
    path: 'userRoles/edit/:id',
    component: UserRoleEditComponent,
    title: $localize`:@@userRole.edit.headline:Edit User Role`
  },
  {
    path: 'manufacturers',
    component: ManufacturerListComponent,
    title: $localize`:@@manufacturer.list.headline:Manufacturers`
  },
  {
    path: 'manufacturers/add',
    component: ManufacturerAddComponent,
    title: $localize`:@@manufacturer.add.headline:Add Manufacturer`
  },
  {
    path: 'manufacturers/edit/:id',
    component: ManufacturerEditComponent,
    title: $localize`:@@manufacturer.edit.headline:Edit Manufacturer`
  },
  {
    path: 'suppliers',
    component: SupplierListComponent,
    title: $localize`:@@supplier.list.headline:Suppliers`
  },
  {
    path: 'suppliers/add',
    component: SupplierAddComponent,
    title: $localize`:@@supplier.add.headline:Add Supplier`
  },
  {
    path: 'suppliers/edit/:id',
    component: SupplierEditComponent,
    title: $localize`:@@supplier.edit.headline:Edit Supplier`
  },
  {
    path: 'categories',
    component: CategoryListComponent,
    title: $localize`:@@category.list.headline:Categories`
  },
  {
    path: 'categories/add',
    component: CategoryAddComponent,
    title: $localize`:@@category.add.headline:Add Category`
  },
  {
    path: 'categories/edit/:id',
    component: CategoryEditComponent,
    title: $localize`:@@category.edit.headline:Edit Category`
  },
  {
    path: 'materialStatuses',
    component: MaterialStatusListComponent,
    title: $localize`:@@materialStatus.list.headline:Material Statuses`
  },
  {
    path: 'materialStatuses/add',
    component: MaterialStatusAddComponent,
    title: $localize`:@@materialStatus.add.headline:Add Material Status`
  },
  {
    path: 'materialStatuses/edit/:id',
    component: MaterialStatusEditComponent,
    title: $localize`:@@materialStatus.edit.headline:Edit Material Status`
  },
  {
    path: 'materials',
    component: MaterialListComponent,
    title: $localize`:@@material.list.headline:Materials`
  },
  {
    path: 'materials/add',
    component: MaterialAddComponent,
    title: $localize`:@@material.add.headline:Add Material`
  },
  {
    path: 'materials/edit/:id',
    component: MaterialEditComponent,
    title: $localize`:@@material.edit.headline:Edit Material`
  },
  {
    path: 'locations',
    component: LocationListComponent,
    title: $localize`:@@location.list.headline:Locations`
  },
  {
    path: 'locations/add',
    component: LocationAddComponent,
    title: $localize`:@@location.add.headline:Add Location`
  },
  {
    path: 'locations/edit/:id',
    component: LocationEditComponent,
    title: $localize`:@@location.edit.headline:Edit Location`
  },
  {
    path: 'stocks',
    component: StockListComponent,
    title: $localize`:@@stock.list.headline:Stocks`
  },
  {
    path: 'stocks/add',
    component: StockAddComponent,
    title: $localize`:@@stock.add.headline:Add Stock`
  },
  {
    path: 'stocks/edit/:id',
    component: StockEditComponent,
    title: $localize`:@@stock.edit.headline:Edit Stock`
  },
  {
    path: 'stockMovements',
    component: StockMovementListComponent,
    title: $localize`:@@stockMovement.list.headline:Stock Movements`
  },
  {
    path: 'stockMovements/add',
    component: StockMovementAddComponent,
    title: $localize`:@@stockMovement.add.headline:Add Stock Movement`
  },
  {
    path: 'stockMovements/edit/:id',
    component: StockMovementEditComponent,
    title: $localize`:@@stockMovement.edit.headline:Edit Stock Movement`
  },
  {
    path: 'clients',
    component: ClientListComponent,
    title: $localize`:@@client.list.headline:Clients`
  },
  {
    path: 'clients/add',
    component: ClientAddComponent,
    title: $localize`:@@client.add.headline:Add Client`
  },
  {
    path: 'clients/edit/:id',
    component: ClientEditComponent,
    title: $localize`:@@client.edit.headline:Edit Client`
  },
  {
    path: 'shipments',
    component: ShipmentListComponent,
    title: $localize`:@@shipment.list.headline:Shipments`
  },
  {
    path: 'shipments/add',
    component: ShipmentAddComponent,
    title: $localize`:@@shipment.add.headline:Add Shipment`
  },
  {
    path: 'shipments/edit/:id',
    component: ShipmentEditComponent,
    title: $localize`:@@shipment.edit.headline:Edit Shipment`
  },
  {
    path: 'shipmentItems',
    component: ShipmentItemListComponent,
    title: $localize`:@@shipmentItem.list.headline:Shipment Items`
  },
  {
    path: 'shipmentItems/add',
    component: ShipmentItemAddComponent,
    title: $localize`:@@shipmentItem.add.headline:Add Shipment Item`
  },
  {
    path: 'shipmentItems/edit/:id',
    component: ShipmentItemEditComponent,
    title: $localize`:@@shipmentItem.edit.headline:Edit Shipment Item`
  },
  {
    path: 'receptions',
    component: ReceptionListComponent,
    title: $localize`:@@reception.list.headline:Receptions`
  },
  {
    path: 'receptions/add',
    component: ReceptionAddComponent,
    title: $localize`:@@reception.add.headline:Add Reception`
  },
  {
    path: 'receptions/edit/:id',
    component: ReceptionEditComponent,
    title: $localize`:@@reception.edit.headline:Edit Reception`
  },
  {
    path: 'receptionItems',
    component: ReceptionItemListComponent,
    title: $localize`:@@receptionItem.list.headline:Reception Items`
  },
  {
    path: 'receptionItems/add',
    component: ReceptionItemAddComponent,
    title: $localize`:@@receptionItem.add.headline:Add Reception Item`
  },
  {
    path: 'receptionItems/edit/:id',
    component: ReceptionItemEditComponent,
    title: $localize`:@@receptionItem.edit.headline:Edit Reception Item`
  },
  {
    path: 'maintenanceRecords',
    component: MaintenanceRecordListComponent,
    title: $localize`:@@maintenanceRecord.list.headline:Maintenance Records`
  },
  {
    path: 'maintenanceRecords/add',
    component: MaintenanceRecordAddComponent,
    title: $localize`:@@maintenanceRecord.add.headline:Add Maintenance Record`
  },
  {
    path: 'maintenanceRecords/edit/:id',
    component: MaintenanceRecordEditComponent,
    title: $localize`:@@maintenanceRecord.edit.headline:Edit Maintenance Record`
  },
  {
    path: 'documents',
    component: DocumentListComponent,
    title: $localize`:@@document.list.headline:Documents`
  },
  {
    path: 'documents/add',
    component: DocumentAddComponent,
    title: $localize`:@@document.add.headline:Add Document`
  },
  {
    path: 'documents/edit/:id',
    component: DocumentEditComponent,
    title: $localize`:@@document.edit.headline:Edit Document`
  },
  {
    path: 'borrowRequests',
    component: BorrowRequestListComponent,
    title: $localize`:@@borrowRequest.list.headline:Borrow Requests`
  },
  {
    path: 'borrowRequests/add',
    component: BorrowRequestAddComponent,
    title: $localize`:@@borrowRequest.add.headline:Add Borrow Request`
  },
  {
    path: 'borrowRequests/edit/:id',
    component: BorrowRequestEditComponent,
    title: $localize`:@@borrowRequest.edit.headline:Edit Borrow Request`
  },
  {
    path: 'alerts',
    component: AlertListComponent,
    title: $localize`:@@alert.list.headline:Alerts`
  },
  {
    path: 'alerts/add',
    component: AlertAddComponent,
    title: $localize`:@@alert.add.headline:Add Alert`
  },
  {
    path: 'alerts/edit/:id',
    component: AlertEditComponent,
    title: $localize`:@@alert.edit.headline:Edit Alert`
  },
  {
    path: 'activityLogs',
    component: ActivityLogListComponent,
    title: $localize`:@@activityLog.list.headline:Activity Logs`
  },
  {
    path: 'activityLogs/add',
    component: ActivityLogAddComponent,
    title: $localize`:@@activityLog.add.headline:Add Activity Log`
  },
  {
    path: 'activityLogs/edit/:id',
    component: ActivityLogEditComponent,
    title: $localize`:@@activityLog.edit.headline:Edit Activity Log`
  },
  {
    path: 'messages',
    component: MessageListComponent,
    title: $localize`:@@message.list.headline:Messages`
  },
  {
    path: 'messages/add',
    component: MessageAddComponent,
    title: $localize`:@@message.add.headline:Add Message`
  },
  {
    path: 'messages/edit/:id',
    component: MessageEditComponent,
    title: $localize`:@@message.edit.headline:Edit Message`
  },
  {
    path: 'error',
    component: ErrorComponent,
    title: $localize`:@@error.page.headline:Error`
  },
  {
    path: '**',
    component: ErrorComponent,
    title: $localize`:@@notFound.headline:Page not found`
  }
];
