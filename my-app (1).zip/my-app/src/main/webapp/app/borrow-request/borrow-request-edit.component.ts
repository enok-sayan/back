import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { BorrowRequestService } from 'app/borrow-request/borrow-request.service';
import { BorrowRequestDTO } from 'app/borrow-request/borrow-request.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-borrow-request-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './borrow-request-edit.component.html'
})
export class BorrowRequestEditComponent implements OnInit {

  borrowRequestService = inject(BorrowRequestService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  userValues?: Map<number,string>;
  materialValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    requestDate: new FormControl(null, [validOffsetDateTime]),
    startDate: new FormControl(null, [validOffsetDateTime]),
    endDate: new FormControl(null, [validOffsetDateTime]),
    status: new FormControl(null),
    purpose: new FormControl(null),
    comments: new FormControl(null),
    user: new FormControl(null),
    material: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@borrowRequest.update.success:Borrow Request was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.borrowRequestService.getUserValues()
        .subscribe({
          next: (data) => this.userValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.borrowRequestService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.borrowRequestService.getBorrowRequest(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new BorrowRequestDTO(this.editForm.value);
    this.borrowRequestService.updateBorrowRequest(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/borrowRequests'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
