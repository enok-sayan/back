import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { BorrowRequestDTO } from 'app/borrow-request/borrow-request.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class BorrowRequestService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/borrowRequests';

  getAllBorrowRequests() {
    return this.http.get<BorrowRequestDTO[]>(this.resourcePath);
  }

  getBorrowRequest(id: number) {
    return this.http.get<BorrowRequestDTO>(this.resourcePath + '/' + id);
  }

  createBorrowRequest(borrowRequestDTO: BorrowRequestDTO) {
    return this.http.post<number>(this.resourcePath, borrowRequestDTO);
  }

  updateBorrowRequest(id: number, borrowRequestDTO: BorrowRequestDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, borrowRequestDTO);
  }

  deleteBorrowRequest(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/userValues')
        .pipe(map(transformRecordToMap));
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

}
