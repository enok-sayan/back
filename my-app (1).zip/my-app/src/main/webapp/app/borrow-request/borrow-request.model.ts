export class BorrowRequestDTO {

  constructor(data:Partial<BorrowRequestDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  requestDate?: string|null;
  startDate?: string|null;
  endDate?: string|null;
  status?: string|null;
  purpose?: string|null;
  comments?: string|null;
  user?: number|null;
  material?: number|null;

}
