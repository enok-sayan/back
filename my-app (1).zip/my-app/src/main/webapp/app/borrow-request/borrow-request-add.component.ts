import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { BorrowRequestService } from 'app/borrow-request/borrow-request.service';
import { BorrowRequestDTO } from 'app/borrow-request/borrow-request.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-borrow-request-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './borrow-request-add.component.html'
})
export class BorrowRequestAddComponent implements OnInit {

  borrowRequestService = inject(BorrowRequestService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  userValues?: Map<number,string>;
  materialValues?: Map<number,string>;

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    requestDate: new FormControl(null, [validOffsetDateTime]),
    startDate: new FormControl(null, [validOffsetDateTime]),
    endDate: new FormControl(null, [validOffsetDateTime]),
    status: new FormControl(null),
    purpose: new FormControl(null),
    comments: new FormControl(null),
    user: new FormControl(null),
    material: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@borrowRequest.create.success:Borrow Request was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.borrowRequestService.getUserValues()
        .subscribe({
          next: (data) => this.userValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.borrowRequestService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new BorrowRequestDTO(this.addForm.value);
    this.borrowRequestService.createBorrowRequest(data)
        .subscribe({
          next: () => this.router.navigate(['/borrowRequests'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
