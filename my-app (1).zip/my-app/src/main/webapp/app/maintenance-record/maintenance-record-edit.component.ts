import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { MaintenanceRecordService } from 'app/maintenance-record/maintenance-record.service';
import { MaintenanceRecordDTO } from 'app/maintenance-record/maintenance-record.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { updateForm, validNumeric, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-maintenance-record-edit',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './maintenance-record-edit.component.html'
})
export class MaintenanceRecordEditComponent implements OnInit {

  maintenanceRecordService = inject(MaintenanceRecordService);
  route = inject(ActivatedRoute);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  materialValues?: Map<number,string>;
  technicianValues?: Map<number,string>;
  currentId?: number;

  editForm = new FormGroup({
    id: new FormControl({ value: null, disabled: true }),
    createdAt: new FormControl(null, [validOffsetDateTime]),
    maintenanceDate: new FormControl(null, [Validators.required]),
    maintenanceType: new FormControl(null, [Validators.required]),
    description: new FormControl(null),
    cost: new FormControl(null, [validNumeric(10, 2)]),
    completed: new FormControl(false),
    material: new FormControl(null),
    technician: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      updated: $localize`:@@maintenanceRecord.update.success:Maintenance Record was updated successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.currentId = +this.route.snapshot.params['id'];
    this.maintenanceRecordService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.maintenanceRecordService.getTechnicianValues()
        .subscribe({
          next: (data) => this.technicianValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.maintenanceRecordService.getMaintenanceRecord(this.currentId!)
        .subscribe({
          next: (data) => updateForm(this.editForm, data),
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.editForm.markAllAsTouched();
    if (!this.editForm.valid) {
      return;
    }
    const data = new MaintenanceRecordDTO(this.editForm.value);
    this.maintenanceRecordService.updateMaintenanceRecord(this.currentId!, data)
        .subscribe({
          next: () => this.router.navigate(['/maintenanceRecords'], {
            state: {
              msgSuccess: this.getMessage('updated')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.editForm, this.getMessage)
        });
  }

}
