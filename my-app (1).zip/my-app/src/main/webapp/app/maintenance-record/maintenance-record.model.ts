export class MaintenanceRecordDTO {

  constructor(data:Partial<MaintenanceRecordDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  maintenanceDate?: string|null;
  maintenanceType?: string|null;
  description?: string|null;
  cost?: string|null;
  completed?: boolean|null;
  material?: number|null;
  technician?: number|null;

}
