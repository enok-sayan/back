import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { MaintenanceRecordDTO } from 'app/maintenance-record/maintenance-record.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class MaintenanceRecordService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/maintenanceRecords';

  getAllMaintenanceRecords() {
    return this.http.get<MaintenanceRecordDTO[]>(this.resourcePath);
  }

  getMaintenanceRecord(id: number) {
    return this.http.get<MaintenanceRecordDTO>(this.resourcePath + '/' + id);
  }

  createMaintenanceRecord(maintenanceRecordDTO: MaintenanceRecordDTO) {
    return this.http.post<number>(this.resourcePath, maintenanceRecordDTO);
  }

  updateMaintenanceRecord(id: number, maintenanceRecordDTO: MaintenanceRecordDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, maintenanceRecordDTO);
  }

  deleteMaintenanceRecord(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

  getTechnicianValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/technicianValues')
        .pipe(map(transformRecordToMap));
  }

}
