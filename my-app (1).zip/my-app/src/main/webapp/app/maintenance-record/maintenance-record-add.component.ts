import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormControl, FormGroup, Validators } from '@angular/forms';
import { InputRowComponent } from 'app/common/input-row/input-row.component';
import { MaintenanceRecordService } from 'app/maintenance-record/maintenance-record.service';
import { MaintenanceRecordDTO } from 'app/maintenance-record/maintenance-record.model';
import { ErrorHandler } from 'app/common/error-handler.injectable';
import { validNumeric, validOffsetDateTime } from 'app/common/utils';


@Component({
  selector: 'app-maintenance-record-add',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, InputRowComponent],
  templateUrl: './maintenance-record-add.component.html'
})
export class MaintenanceRecordAddComponent implements OnInit {

  maintenanceRecordService = inject(MaintenanceRecordService);
  router = inject(Router);
  errorHandler = inject(ErrorHandler);

  materialValues?: Map<number,string>;
  technicianValues?: Map<number,string>;

  addForm = new FormGroup({
    createdAt: new FormControl(null, [validOffsetDateTime]),
    maintenanceDate: new FormControl(null, [Validators.required]),
    maintenanceType: new FormControl(null, [Validators.required]),
    description: new FormControl(null),
    cost: new FormControl(null, [validNumeric(10, 2)]),
    completed: new FormControl(false),
    material: new FormControl(null),
    technician: new FormControl(null)
  }, { updateOn: 'submit' });

  getMessage(key: string, details?: any) {
    const messages: Record<string, string> = {
      created: $localize`:@@maintenanceRecord.create.success:Maintenance Record was created successfully.`
    };
    return messages[key];
  }

  ngOnInit() {
    this.maintenanceRecordService.getMaterialValues()
        .subscribe({
          next: (data) => this.materialValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
    this.maintenanceRecordService.getTechnicianValues()
        .subscribe({
          next: (data) => this.technicianValues = data,
          error: (error) => this.errorHandler.handleServerError(error.error)
        });
  }

  handleSubmit() {
    window.scrollTo(0, 0);
    this.addForm.markAllAsTouched();
    if (!this.addForm.valid) {
      return;
    }
    const data = new MaintenanceRecordDTO(this.addForm.value);
    this.maintenanceRecordService.createMaintenanceRecord(data)
        .subscribe({
          next: () => this.router.navigate(['/maintenanceRecords'], {
            state: {
              msgSuccess: this.getMessage('created')
            }
          }),
          error: (error) => this.errorHandler.handleServerError(error.error, this.addForm, this.getMessage)
        });
  }

}
