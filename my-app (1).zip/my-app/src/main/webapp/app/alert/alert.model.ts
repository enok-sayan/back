export class AlertDTO {

  constructor(data:Partial<AlertDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  alertType?: string|null;
  message?: string|null;
  timestamp?: string|null;
  isRead?: boolean|null;
  user?: number|null;
  material?: number|null;

}
