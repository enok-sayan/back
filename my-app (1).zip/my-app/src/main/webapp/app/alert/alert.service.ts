import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { AlertDTO } from 'app/alert/alert.model';
import { map } from 'rxjs';
import { transformRecordToMap } from 'app/common/utils';


@Injectable({
  providedIn: 'root',
})
export class AlertService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/alerts';

  getAllAlerts() {
    return this.http.get<AlertDTO[]>(this.resourcePath);
  }

  getAlert(id: number) {
    return this.http.get<AlertDTO>(this.resourcePath + '/' + id);
  }

  createAlert(alertDTO: AlertDTO) {
    return this.http.post<number>(this.resourcePath, alertDTO);
  }

  updateAlert(id: number, alertDTO: AlertDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, alertDTO);
  }

  deleteAlert(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

  getUserValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/userValues')
        .pipe(map(transformRecordToMap));
  }

  getMaterialValues() {
    return this.http.get<Record<string, number>>(this.resourcePath + '/materialValues')
        .pipe(map(transformRecordToMap));
  }

}
