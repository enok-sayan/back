export class ClientDTO {

  constructor(data:Partial<ClientDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  contactPerson?: string|null;
  phone?: string|null;
  email?: string|null;
  address?: string|null;

}
