export class MaterialStatusDTO {

  constructor(data:Partial<MaterialStatusDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  description?: string|null;

}
