import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'environments/environment';
import { MaterialStatusDTO } from 'app/material-status/material-status.model';


@Injectable({
  providedIn: 'root',
})
export class MaterialStatusService {

  http = inject(HttpClient);
  resourcePath = environment.apiPath + '/api/materialStatuses';

  getAllMaterialStatuses() {
    return this.http.get<MaterialStatusDTO[]>(this.resourcePath);
  }

  getMaterialStatus(id: number) {
    return this.http.get<MaterialStatusDTO>(this.resourcePath + '/' + id);
  }

  createMaterialStatus(materialStatusDTO: MaterialStatusDTO) {
    return this.http.post<number>(this.resourcePath, materialStatusDTO);
  }

  updateMaterialStatus(id: number, materialStatusDTO: MaterialStatusDTO) {
    return this.http.put<number>(this.resourcePath + '/' + id, materialStatusDTO);
  }

  deleteMaterialStatus(id: number) {
    return this.http.delete(this.resourcePath + '/' + id);
  }

}
