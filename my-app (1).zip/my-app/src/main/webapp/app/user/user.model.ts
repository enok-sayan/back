export class UserDTO {

  constructor(data:Partial<UserDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  name?: string|null;
  email?: string|null;
  password?: string|null;
  username?: string|null;
  firstName?: string|null;
  lastName?: string|null;
  phone?: string|null;
  dateOfBirth?: string|null;
  emailVerified?: boolean|null;
  userType?: number|null;

}
