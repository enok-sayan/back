export class DocumentDTO {

  constructor(data:Partial<DocumentDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  fileUrl?: string|null;
  fileType?: string|null;
  description?: string|null;
  material?: number|null;

}
