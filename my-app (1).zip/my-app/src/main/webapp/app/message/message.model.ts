export class MessageDTO {

  constructor(data:Partial<MessageDTO>) {
    Object.assign(this, data);
  }

  id?: number|null;
  createdAt?: string|null;
  subject?: string|null;
  content?: string|null;
  sentAt?: string|null;
  readAt?: string|null;
  sender?: number|null;
  receiver?: number|null;
  parentMessage?: number|null;

}
